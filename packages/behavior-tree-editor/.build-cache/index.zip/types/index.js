/**
 * 默认编辑器配置
 */
export const DEFAULT_EDITOR_CONFIG = {
    enableSnapping: true,
    gridSize: 20,
    minZoom: 0.1,
    maxZoom: 3,
    showGrid: true,
    showMinimap: false
};
//# sourceMappingURL=index.js.map