import type { BehaviorTree } from '../domain/models/BehaviorTree';
export declare class BehaviorTreeService {
    createNew(): Promise<void>;
    loadFromFile(filePath: string): Promise<void>;
    saveToFile(filePath: string): Promise<void>;
    getCurrentTree(): BehaviorTree;
    setTree(tree: BehaviorTree): void;
}
//# sourceMappingURL=BehaviorTreeService.d.ts.map