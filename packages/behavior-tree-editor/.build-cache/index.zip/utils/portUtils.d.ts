import { RefObject } from 'react';
import { Node as BehaviorTreeNode } from '../domain/models/Node';
/**
 * 获取端口在画布逻辑坐标系中的位置
 * 画布逻辑坐标：与 node.position 一致的坐标系，未经过 transform 的逻辑坐标
 *
 * @returns 端口中心点的画布逻辑坐标，如果端口不存在则返回 null
 */
export declare function getPortPosition(canvasRef: RefObject<HTMLDivElement>, canvasOffset: {
    x: number;
    y: number;
}, canvasScale: number, nodes: BehaviorTreeNode[], nodeId: string, propertyName?: string, portType?: 'input' | 'output'): {
    x: number;
    y: number;
} | null;
//# sourceMappingURL=portUtils.d.ts.map