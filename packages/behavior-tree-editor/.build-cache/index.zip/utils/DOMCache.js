export class DOMCache {
    constructor() {
        this.nodeElements = new Map();
        this.connectionElements = new Map();
        this.lastNodeStatus = new Map();
        this.statusTimers = new Map();
    }
    getNode(nodeId) {
        let element = this.nodeElements.get(nodeId);
        if (!element) {
            element = document.querySelector(`[data-node-id="${nodeId}"]`) || undefined;
            if (element) {
                this.nodeElements.set(nodeId, element);
            }
        }
        return element;
    }
    getConnection(connectionKey) {
        let element = this.connectionElements.get(connectionKey);
        if (!element) {
            element = document.querySelector(`[data-connection-id="${connectionKey}"]`) || undefined;
            if (element) {
                this.connectionElements.set(connectionKey, element);
            }
        }
        return element;
    }
    getLastStatus(nodeId) {
        return this.lastNodeStatus.get(nodeId);
    }
    setLastStatus(nodeId, status) {
        this.lastNodeStatus.set(nodeId, status);
    }
    hasStatusChanged(nodeId, newStatus) {
        return this.lastNodeStatus.get(nodeId) !== newStatus;
    }
    getStatusTimer(nodeId) {
        return this.statusTimers.get(nodeId);
    }
    setStatusTimer(nodeId, timerId) {
        this.statusTimers.set(nodeId, timerId);
    }
    clearStatusTimer(nodeId) {
        const timerId = this.statusTimers.get(nodeId);
        if (timerId) {
            clearTimeout(timerId);
            this.statusTimers.delete(nodeId);
        }
    }
    clearAllStatusTimers() {
        this.statusTimers.forEach((timerId) => clearTimeout(timerId));
        this.statusTimers.clear();
    }
    clearNodeCache() {
        this.nodeElements.clear();
    }
    clearConnectionCache() {
        this.connectionElements.clear();
    }
    clearStatusCache() {
        this.lastNodeStatus.clear();
    }
    clearAll() {
        this.clearNodeCache();
        this.clearConnectionCache();
        this.clearStatusCache();
        this.clearAllStatusTimers();
    }
    removeNodeClasses(nodeId, ...classes) {
        const element = this.getNode(nodeId);
        if (element) {
            element.classList.remove(...classes);
        }
    }
    addNodeClasses(nodeId, ...classes) {
        const element = this.getNode(nodeId);
        if (element) {
            element.classList.add(...classes);
        }
    }
    hasNodeClass(nodeId, className) {
        const element = this.getNode(nodeId);
        return element?.classList.contains(className) || false;
    }
    setConnectionAttribute(connectionKey, attribute, value) {
        const element = this.getConnection(connectionKey);
        if (element) {
            element.setAttribute(attribute, value);
        }
    }
    getConnectionAttribute(connectionKey, attribute) {
        const element = this.getConnection(connectionKey);
        return element?.getAttribute(attribute) || null;
    }
    forEachNode(callback) {
        this.nodeElements.forEach((element, nodeId) => {
            callback(element, nodeId);
        });
    }
    forEachConnection(callback) {
        this.connectionElements.forEach((element, connectionKey) => {
            callback(element, connectionKey);
        });
    }
}
//# sourceMappingURL=DOMCache.js.map