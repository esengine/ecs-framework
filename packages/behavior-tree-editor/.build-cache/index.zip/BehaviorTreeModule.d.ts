import { IEditorModule, IModuleContext } from '@esengine/editor-core';
export declare class BehaviorTreeModule implements IEditorModule {
    readonly id = "behavior-tree";
    readonly name = "Behavior Tree Editor";
    readonly version = "1.0.0";
    load(context: IModuleContext): Promise<void>;
    private registerServices;
    private registerCompilers;
    private registerInspectors;
    unload(): Promise<void>;
    private registerCommands;
    private registerPanels;
    private subscribeEvents;
}
//# sourceMappingURL=BehaviorTreeModule.d.ts.map