export type NodeExecutionStatus = 'idle' | 'running' | 'success' | 'failure';
interface ExecutionState {
    isExecuting: boolean;
    nodeExecutionStatuses: Map<string, NodeExecutionStatus>;
    nodeExecutionOrders: Map<string, number>;
    setIsExecuting: (isExecuting: boolean) => void;
    setNodeExecutionStatus: (nodeId: string, status: NodeExecutionStatus) => void;
    updateNodeExecutionStatuses: (statuses: Map<string, NodeExecutionStatus>, orders?: Map<string, number>) => void;
    clearNodeExecutionStatuses: () => void;
}
export declare const useExecutionStore: import("zustand").UseBoundStore<import("zustand").StoreApi<ExecutionState>>;
export {};
//# sourceMappingURL=useExecutionStore.d.ts.map