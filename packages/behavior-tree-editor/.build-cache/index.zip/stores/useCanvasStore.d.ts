interface CanvasState {
    offset: {
        x: number;
        y: number;
    };
    scale: number;
    isPanning: boolean;
    panStart: {
        x: number;
        y: number;
    };
    setOffset: (offset: {
        x: number;
        y: number;
    }) => void;
    setScale: (scale: number) => void;
    setIsPanning: (isPanning: boolean) => void;
    setPanStart: (panStart: {
        x: number;
        y: number;
    }) => void;
    resetView: () => void;
}
export declare const useCanvasStore: import("zustand").UseBoundStore<import("zustand").StoreApi<CanvasState>>;
export {};
//# sourceMappingURL=useCanvasStore.d.ts.map