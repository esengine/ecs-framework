import { Node } from '../domain/models/Node';
import { Connection } from '../domain/models/Connection';
import { Blackboard, BlackboardValue } from '../domain/models/Blackboard';
import { ROOT_NODE_ID } from '../domain/constants/RootNode';
/**
 * 行为树 Store 状态接口
 */
export type NodeExecutionStatus = 'idle' | 'running' | 'success' | 'failure';
export interface NodeExecutionInfo {
    status: NodeExecutionStatus;
    executionOrder?: number;
}
interface BehaviorTreeState {
    isOpen: boolean;
    pendingFilePath: string | null;
    nodes: Node[];
    connections: Connection[];
    blackboard: Blackboard;
    blackboardVariables: Record<string, BlackboardValue>;
    initialBlackboardVariables: Record<string, BlackboardValue>;
    initialNodesData: Map<string, Record<string, unknown>>;
    selectedNodeIds: string[];
    draggingNodeId: string | null;
    dragStartPositions: Map<string, {
        x: number;
        y: number;
    }>;
    isDraggingNode: boolean;
    isExecuting: boolean;
    nodeExecutionStatuses: Map<string, NodeExecutionStatus>;
    nodeExecutionOrders: Map<string, number>;
    canvasOffset: {
        x: number;
        y: number;
    };
    canvasScale: number;
    isPanning: boolean;
    panStart: {
        x: number;
        y: number;
    };
    connectingFrom: string | null;
    connectingFromProperty: string | null;
    connectingToPos: {
        x: number;
        y: number;
    } | null;
    isBoxSelecting: boolean;
    boxSelectStart: {
        x: number;
        y: number;
    } | null;
    boxSelectEnd: {
        x: number;
        y: number;
    } | null;
    dragDelta: {
        dx: number;
        dy: number;
    };
    forceUpdateCounter: number;
    setNodes: (nodes: Node[]) => void;
    updateNodes: (updater: (nodes: Node[]) => Node[]) => void;
    addNode: (node: Node) => void;
    removeNodes: (nodeIds: string[]) => void;
    updateNodePosition: (nodeId: string, position: {
        x: number;
        y: number;
    }) => void;
    updateNodesPosition: (updates: Map<string, {
        x: number;
        y: number;
    }>) => void;
    updateNodeData: (nodeId: string, data: Record<string, unknown>) => void;
    setConnections: (connections: Connection[]) => void;
    addConnection: (connection: Connection) => void;
    removeConnections: (filter: (conn: Connection) => boolean) => void;
    setSelectedNodeIds: (nodeIds: string[]) => void;
    toggleNodeSelection: (nodeId: string) => void;
    clearSelection: () => void;
    startDragging: (nodeId: string, startPositions: Map<string, {
        x: number;
        y: number;
    }>) => void;
    stopDragging: () => void;
    setIsDraggingNode: (isDragging: boolean) => void;
    setCanvasOffset: (offset: {
        x: number;
        y: number;
    }) => void;
    setCanvasScale: (scale: number) => void;
    setIsPanning: (isPanning: boolean) => void;
    setPanStart: (panStart: {
        x: number;
        y: number;
    }) => void;
    resetView: () => void;
    setConnectingFrom: (nodeId: string | null) => void;
    setConnectingFromProperty: (propertyName: string | null) => void;
    setConnectingToPos: (pos: {
        x: number;
        y: number;
    } | null) => void;
    clearConnecting: () => void;
    setIsBoxSelecting: (isSelecting: boolean) => void;
    setBoxSelectStart: (pos: {
        x: number;
        y: number;
    } | null) => void;
    setBoxSelectEnd: (pos: {
        x: number;
        y: number;
    } | null) => void;
    clearBoxSelect: () => void;
    setDragDelta: (delta: {
        dx: number;
        dy: number;
    }) => void;
    triggerForceUpdate: () => void;
    setBlackboard: (blackboard: Blackboard) => void;
    updateBlackboardVariable: (name: string, value: BlackboardValue) => void;
    setBlackboardVariables: (variables: Record<string, BlackboardValue>) => void;
    setInitialBlackboardVariables: (variables: Record<string, BlackboardValue>) => void;
    setIsExecuting: (isExecuting: boolean) => void;
    saveNodesDataSnapshot: () => void;
    restoreNodesData: () => void;
    setNodeExecutionStatus: (nodeId: string, status: NodeExecutionStatus) => void;
    updateNodeExecutionStatuses: (statuses: Map<string, NodeExecutionStatus>, orders?: Map<string, number>) => void;
    clearNodeExecutionStatuses: () => void;
    sortChildrenByPosition: () => void;
    exportToJSON: (metadata: {
        name: string;
        description: string;
    }) => string;
    importFromJSON: (json: string) => void;
    exportToRuntimeAsset: (metadata: {
        name: string;
        description: string;
    }, format: 'json' | 'binary') => string | Uint8Array;
    setIsOpen: (isOpen: boolean) => void;
    setPendingFilePath: (filePath: string | null) => void;
    reset: () => void;
}
/**
 * 行为树 Store
 */
export declare const useBehaviorTreeStore: import("zustand").UseBoundStore<import("zustand").StoreApi<BehaviorTreeState>>;
export { ROOT_NODE_ID };
export type { Node as BehaviorTreeNode };
export type { Connection };
//# sourceMappingURL=behaviorTreeStore.d.ts.map