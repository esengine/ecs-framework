import { create } from 'zustand';
import { NodeTemplates, EditorFormatConverter, BehaviorTreeAssetSerializer } from '@esengine/behavior-tree';
import { Node } from '../domain/models/Node';
import { Connection } from '../domain/models/Connection';
import { Blackboard } from '../domain/models/Blackboard';
import { Position } from '../domain/value-objects/Position';
import { createRootNode, ROOT_NODE_ID } from '../domain/constants/RootNode';
import { BehaviorTree } from '../domain/models/BehaviorTree';
import { useBehaviorTreeDataStore } from '../application/state/BehaviorTreeDataStore';
/**
 * 行为树 Store
 */
export const useBehaviorTreeStore = create((set, get) => ({
    isOpen: false,
    pendingFilePath: null,
    nodes: [],
    connections: [],
    blackboard: new Blackboard(),
    blackboardVariables: {},
    initialBlackboardVariables: {},
    initialNodesData: new Map(),
    selectedNodeIds: [],
    draggingNodeId: null,
    dragStartPositions: new Map(),
    isDraggingNode: false,
    isExecuting: false,
    nodeExecutionStatuses: new Map(),
    nodeExecutionOrders: new Map(),
    canvasOffset: { x: 0, y: 0 },
    canvasScale: 1,
    isPanning: false,
    panStart: { x: 0, y: 0 },
    connectingFrom: null,
    connectingFromProperty: null,
    connectingToPos: null,
    isBoxSelecting: false,
    boxSelectStart: null,
    boxSelectEnd: null,
    dragDelta: { dx: 0, dy: 0 },
    forceUpdateCounter: 0,
    setNodes: (nodes) => set({ nodes }),
    updateNodes: (updater) => set((state) => ({
        nodes: updater(state.nodes)
    })),
    addNode: (node) => set((state) => ({
        nodes: [...state.nodes, node]
    })),
    removeNodes: (nodeIds) => set((state) => {
        const nodesToDelete = new Set(nodeIds);
        const remainingNodes = state.nodes
            .filter((n) => !nodesToDelete.has(n.id))
            .map((n) => {
            const newChildren = Array.from(n.children).filter((childId) => !nodesToDelete.has(childId));
            if (newChildren.length !== n.children.length) {
                return new Node(n.id, n.template, n.data, n.position, newChildren);
            }
            return n;
        });
        return { nodes: remainingNodes };
    }),
    updateNodePosition: (nodeId, position) => set((state) => ({
        nodes: state.nodes.map((n) => n.id === nodeId ? new Node(n.id, n.template, n.data, new Position(position.x, position.y), Array.from(n.children)) : n)
    })),
    updateNodesPosition: (updates) => set((state) => ({
        nodes: state.nodes.map((node) => {
            const newPos = updates.get(node.id);
            return newPos ? new Node(node.id, node.template, node.data, new Position(newPos.x, newPos.y), Array.from(node.children)) : node;
        })
    })),
    updateNodeData: (nodeId, data) => set((state) => ({
        nodes: state.nodes.map((n) => n.id === nodeId ? new Node(n.id, n.template, data, n.position, Array.from(n.children)) : n)
    })),
    setConnections: (connections) => set({ connections }),
    addConnection: (connection) => set((state) => ({
        connections: [...state.connections, connection]
    })),
    removeConnections: (filter) => set((state) => ({
        connections: state.connections.filter(filter)
    })),
    setSelectedNodeIds: (nodeIds) => set({ selectedNodeIds: nodeIds }),
    toggleNodeSelection: (nodeId) => set((state) => ({
        selectedNodeIds: state.selectedNodeIds.includes(nodeId)
            ? state.selectedNodeIds.filter((id) => id !== nodeId)
            : [...state.selectedNodeIds, nodeId]
    })),
    clearSelection: () => set({ selectedNodeIds: [] }),
    startDragging: (nodeId, startPositions) => set({
        draggingNodeId: nodeId,
        dragStartPositions: startPositions
    }),
    stopDragging: () => set({ draggingNodeId: null }),
    setIsDraggingNode: (isDragging) => set({ isDraggingNode: isDragging }),
    setCanvasOffset: (offset) => set({ canvasOffset: offset }),
    setCanvasScale: (scale) => set({ canvasScale: scale }),
    setIsPanning: (isPanning) => set({ isPanning }),
    setPanStart: (panStart) => set({ panStart }),
    resetView: () => set({ canvasOffset: { x: 0, y: 0 }, canvasScale: 1 }),
    setConnectingFrom: (nodeId) => set({ connectingFrom: nodeId }),
    setConnectingFromProperty: (propertyName) => set({ connectingFromProperty: propertyName }),
    setConnectingToPos: (pos) => set({ connectingToPos: pos }),
    clearConnecting: () => set({
        connectingFrom: null,
        connectingFromProperty: null,
        connectingToPos: null
    }),
    setIsBoxSelecting: (isSelecting) => set({ isBoxSelecting: isSelecting }),
    setBoxSelectStart: (pos) => set({ boxSelectStart: pos }),
    setBoxSelectEnd: (pos) => set({ boxSelectEnd: pos }),
    clearBoxSelect: () => set({
        isBoxSelecting: false,
        boxSelectStart: null,
        boxSelectEnd: null
    }),
    setDragDelta: (delta) => set({ dragDelta: delta }),
    triggerForceUpdate: () => set((state) => ({ forceUpdateCounter: state.forceUpdateCounter + 1 })),
    setBlackboard: (blackboard) => set({
        blackboard,
        blackboardVariables: blackboard.toObject()
    }),
    updateBlackboardVariable: (name, value) => set((state) => {
        const newBlackboard = Blackboard.fromObject(state.blackboard.toObject());
        newBlackboard.setValue(name, value);
        return {
            blackboard: newBlackboard,
            blackboardVariables: newBlackboard.toObject()
        };
    }),
    setBlackboardVariables: (variables) => set(() => {
        const newBlackboard = Blackboard.fromObject(variables);
        return {
            blackboard: newBlackboard,
            blackboardVariables: variables
        };
    }),
    setInitialBlackboardVariables: (variables) => set({
        initialBlackboardVariables: variables
    }),
    setIsExecuting: (isExecuting) => set({ isExecuting }),
    saveNodesDataSnapshot: () => {
        const snapshot = new Map();
        get().nodes.forEach(node => {
            snapshot.set(node.id, { ...node.data });
        });
        set({ initialNodesData: snapshot });
    },
    restoreNodesData: () => {
        const snapshot = get().initialNodesData;
        if (snapshot.size === 0)
            return;
        const updatedNodes = get().nodes.map(node => {
            const savedData = snapshot.get(node.id);
            if (savedData) {
                return new Node(node.id, node.template, savedData, node.position, Array.from(node.children));
            }
            return node;
        });
        set({ nodes: updatedNodes, initialNodesData: new Map() });
    },
    setNodeExecutionStatus: (nodeId, status) => {
        const newStatuses = new Map(get().nodeExecutionStatuses);
        newStatuses.set(nodeId, status);
        set({ nodeExecutionStatuses: newStatuses });
    },
    updateNodeExecutionStatuses: (statuses, orders) => {
        set({
            nodeExecutionStatuses: new Map(statuses),
            nodeExecutionOrders: orders ? new Map(orders) : new Map()
        });
    },
    clearNodeExecutionStatuses: () => {
        set({ nodeExecutionStatuses: new Map(), nodeExecutionOrders: new Map() });
    },
    sortChildrenByPosition: () => set((state) => {
        const nodeMap = new Map();
        state.nodes.forEach((node) => nodeMap.set(node.id, node));
        const sortedNodes = state.nodes.map((node) => {
            if (node.children.length <= 1) {
                return node;
            }
            const sortedChildren = Array.from(node.children).sort((a, b) => {
                const nodeA = nodeMap.get(a);
                const nodeB = nodeMap.get(b);
                if (!nodeA || !nodeB)
                    return 0;
                return nodeA.position.x - nodeB.position.x;
            });
            return new Node(node.id, node.template, node.data, node.position, sortedChildren);
        });
        return { nodes: sortedNodes };
    }),
    exportToJSON: (metadata) => {
        const state = get();
        const now = new Date().toISOString();
        const data = {
            version: '1.0.0',
            metadata: {
                name: metadata.name,
                description: metadata.description,
                createdAt: now,
                modifiedAt: now
            },
            nodes: state.nodes.map((n) => n.toObject()),
            connections: state.connections.map((c) => c.toObject()),
            blackboard: state.blackboard.toObject(),
            canvasState: {
                offset: state.canvasOffset,
                scale: state.canvasScale
            }
        };
        return JSON.stringify(data, null, 2);
    },
    importFromJSON: (json) => {
        const data = JSON.parse(json);
        const blackboardData = data.blackboard || {};
        const loadedNodes = (data.nodes || []).map((nodeObj) => {
            if (nodeObj.id === ROOT_NODE_ID) {
                return createRootNode();
            }
            const className = nodeObj.template?.className;
            let template = nodeObj.template;
            if (className) {
                const allTemplates = NodeTemplates.getAllTemplates();
                const latestTemplate = allTemplates.find((t) => t.className === className);
                if (latestTemplate) {
                    template = latestTemplate;
                }
            }
            const position = new Position(nodeObj.position.x, nodeObj.position.y);
            return new Node(nodeObj.id, template, nodeObj.data, position, nodeObj.children || []);
        });
        const loadedConnections = (data.connections || []).map((connObj) => {
            return new Connection(connObj.from, connObj.to, connObj.connectionType || 'node', connObj.fromProperty, connObj.toProperty);
        });
        const loadedBlackboard = Blackboard.fromObject(blackboardData);
        // 同步更新领域层数据存储，确保 Command 系统使用正确的数据
        const newTree = new BehaviorTree(loadedNodes, loadedConnections, loadedBlackboard, ROOT_NODE_ID);
        useBehaviorTreeDataStore.getState().setTree(newTree);
        set({
            isOpen: true,
            nodes: loadedNodes,
            connections: loadedConnections,
            blackboard: loadedBlackboard,
            blackboardVariables: blackboardData,
            initialBlackboardVariables: blackboardData,
            canvasOffset: data.canvasState?.offset || { x: 0, y: 0 },
            canvasScale: data.canvasState?.scale || 1,
            // 只清理连线相关状态，避免切换文件时残留上一个文件的连线状态
            connectingFrom: null,
            connectingFromProperty: null,
            connectingToPos: null,
            // 清理选中状态
            selectedNodeIds: []
        });
    },
    exportToRuntimeAsset: (metadata, format) => {
        const state = get();
        const editorFormat = {
            version: '1.0.0',
            metadata: {
                name: metadata.name,
                description: metadata.description,
                createdAt: new Date().toISOString(),
                modifiedAt: new Date().toISOString()
            },
            nodes: state.nodes.map((n) => n.toObject()),
            connections: state.connections.map((c) => c.toObject()),
            blackboard: state.blackboard.toObject()
        };
        const asset = EditorFormatConverter.toAsset(editorFormat, metadata);
        return BehaviorTreeAssetSerializer.serialize(asset, {
            format,
            pretty: format === 'json',
            validate: true
        });
    },
    setIsOpen: (isOpen) => set({ isOpen }),
    setPendingFilePath: (filePath) => set({ pendingFilePath: filePath }),
    reset: () => set({
        isOpen: false,
        nodes: [],
        connections: [],
        blackboard: new Blackboard(),
        blackboardVariables: {},
        initialBlackboardVariables: {},
        selectedNodeIds: [],
        draggingNodeId: null,
        dragStartPositions: new Map(),
        isDraggingNode: false,
        isExecuting: false,
        canvasOffset: { x: 0, y: 0 },
        canvasScale: 1,
        isPanning: false,
        panStart: { x: 0, y: 0 },
        connectingFrom: null,
        connectingFromProperty: null,
        connectingToPos: null,
        isBoxSelecting: false,
        boxSelectStart: null,
        boxSelectEnd: null,
        dragDelta: { dx: 0, dy: 0 },
        forceUpdateCounter: 0
    })
}));
export { ROOT_NODE_ID };
//# sourceMappingURL=behaviorTreeStore.js.map