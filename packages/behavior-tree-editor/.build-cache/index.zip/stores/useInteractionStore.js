import { create } from 'zustand';
export const useInteractionStore = create((set) => ({
    draggingNodeId: null,
    dragStartPositions: new Map(),
    isDraggingNode: false,
    dragDelta: { dx: 0, dy: 0 },
    connectingFrom: null,
    connectingFromProperty: null,
    connectingToPos: null,
    startDragging: (nodeId, startPositions) => set({
        draggingNodeId: nodeId,
        dragStartPositions: new Map(startPositions),
        isDraggingNode: true
    }),
    stopDragging: () => set({
        draggingNodeId: null,
        dragStartPositions: new Map(),
        isDraggingNode: false,
        dragDelta: { dx: 0, dy: 0 }
    }),
    setIsDraggingNode: (isDragging) => set({ isDraggingNode: isDragging }),
    setDragDelta: (delta) => set({ dragDelta: delta }),
    setConnectingFrom: (nodeId) => set({ connectingFrom: nodeId }),
    setConnectingFromProperty: (propertyName) => set({ connectingFromProperty: propertyName }),
    setConnectingToPos: (pos) => set({ connectingToPos: pos }),
    clearConnecting: () => set({
        connectingFrom: null,
        connectingFromProperty: null,
        connectingToPos: null
    })
}));
//# sourceMappingURL=useInteractionStore.js.map