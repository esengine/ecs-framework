interface SelectionState {
    selectedNodeIds: string[];
    isBoxSelecting: boolean;
    boxSelectStart: {
        x: number;
        y: number;
    } | null;
    boxSelectEnd: {
        x: number;
        y: number;
    } | null;
    setSelectedNodeIds: (nodeIds: string[]) => void;
    toggleNodeSelection: (nodeId: string) => void;
    clearSelection: () => void;
    setIsBoxSelecting: (isSelecting: boolean) => void;
    setBoxSelectStart: (pos: {
        x: number;
        y: number;
    } | null) => void;
    setBoxSelectEnd: (pos: {
        x: number;
        y: number;
    } | null) => void;
    clearBoxSelect: () => void;
}
export declare const useSelectionStore: import("zustand").UseBoundStore<import("zustand").StoreApi<SelectionState>>;
export {};
//# sourceMappingURL=useSelectionStore.d.ts.map