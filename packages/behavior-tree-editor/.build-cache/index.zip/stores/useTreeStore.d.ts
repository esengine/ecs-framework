import { Node } from '../domain/models/Node';
import { Connection } from '../domain/models/Connection';
import { Blackboard, BlackboardValue } from '../domain/models/Blackboard';
interface TreeState {
    isOpen: boolean;
    pendingFilePath: string | null;
    nodes: Node[];
    connections: Connection[];
    blackboard: Blackboard;
    blackboardVariables: Record<string, BlackboardValue>;
    initialBlackboardVariables: Record<string, BlackboardValue>;
    initialNodesData: Map<string, Record<string, unknown>>;
    forceUpdateCounter: number;
    setNodes: (nodes: Node[]) => void;
    updateNodes: (updater: (nodes: Node[]) => Node[]) => void;
    addNode: (node: Node) => void;
    removeNodes: (nodeIds: string[]) => void;
    updateNodePosition: (nodeId: string, position: {
        x: number;
        y: number;
    }) => void;
    updateNodesPosition: (updates: Map<string, {
        x: number;
        y: number;
    }>) => void;
    updateNodeData: (nodeId: string, data: Record<string, unknown>) => void;
    setConnections: (connections: Connection[]) => void;
    addConnection: (connection: Connection) => void;
    removeConnections: (filter: (conn: Connection) => boolean) => void;
    setBlackboard: (blackboard: Blackboard) => void;
    updateBlackboardVariable: (name: string, value: BlackboardValue) => void;
    setBlackboardVariables: (variables: Record<string, BlackboardValue>) => void;
    setInitialBlackboardVariables: (variables: Record<string, BlackboardValue>) => void;
    saveNodesDataSnapshot: () => void;
    restoreNodesData: () => void;
    sortChildrenByPosition: () => void;
    triggerForceUpdate: () => void;
    exportToJSON: (metadata: {
        name: string;
        description: string;
    }) => string;
    importFromJSON: (json: string) => void;
    exportToRuntimeAsset: (metadata: {
        name: string;
        description: string;
    }, format: 'json' | 'binary') => string | Uint8Array;
    setIsOpen: (isOpen: boolean) => void;
    setPendingFilePath: (filePath: string | null) => void;
    reset: () => void;
}
export declare const useTreeStore: import("zustand").UseBoundStore<import("zustand").StoreApi<TreeState>>;
export {};
//# sourceMappingURL=useTreeStore.d.ts.map