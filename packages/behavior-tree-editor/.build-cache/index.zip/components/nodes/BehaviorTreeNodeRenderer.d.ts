import React from 'react';
import { NodeViewData } from '../../types';
/**
 * 节点渲染器属性
 */
interface BehaviorTreeNodeRendererProps {
    /**
     * 节点视图数据
     */
    nodeData: NodeViewData;
    /**
     * 节点点击事件
     */
    onClick?: (e: React.MouseEvent, nodeId: string) => void;
    /**
     * 节点双击事件
     */
    onDoubleClick?: (e: React.MouseEvent, nodeId: string) => void;
    /**
     * 节点右键事件
     */
    onContextMenu?: (e: React.MouseEvent, nodeId: string) => void;
    /**
     * 鼠标按下事件
     */
    onMouseDown?: (e: React.MouseEvent, nodeId: string) => void;
}
/**
 * 行为树节点渲染器
 * 负责单个节点的渲染
 */
export declare const BehaviorTreeNodeRenderer: React.FC<BehaviorTreeNodeRendererProps>;
export {};
//# sourceMappingURL=BehaviorTreeNodeRenderer.d.ts.map