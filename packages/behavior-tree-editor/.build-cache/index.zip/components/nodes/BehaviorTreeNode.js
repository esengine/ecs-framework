import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { TreePine, Database, AlertTriangle, AlertCircle } from 'lucide-react';
import { ROOT_NODE_ID } from '../../domain/constants/RootNode';
export const BehaviorTreeNode = ({ node, isSelected, isBeingDragged, dragDelta, uncommittedNodeIds, blackboardVariables, initialBlackboardVariables, isExecuting, executionStatus, executionOrder, connections, nodes, executorRef, iconMap, draggingNodeId, onNodeClick, onContextMenu, onNodeMouseDown, onNodeMouseUpForConnection, onPortMouseDown, onPortMouseUp }) => {
    const isRoot = node.id === ROOT_NODE_ID;
    const isBlackboardVariable = node.data.nodeType === 'blackboard-variable';
    const posX = node.position.x + (isBeingDragged ? dragDelta.dx : 0);
    const posY = node.position.y + (isBeingDragged ? dragDelta.dy : 0);
    const isUncommitted = uncommittedNodeIds.has(node.id);
    const nodeClasses = [
        'bt-node',
        isSelected && 'selected',
        isRoot && 'root',
        isUncommitted && 'uncommitted',
        executionStatus && executionStatus !== 'idle' && executionStatus
    ].filter(Boolean).join(' ');
    return (_jsx("div", { "data-node-id": node.id, className: nodeClasses, onClick: (e) => onNodeClick(e, node), onContextMenu: (e) => onContextMenu(e, node), onMouseDown: (e) => onNodeMouseDown(e, node.id), onMouseUp: (e) => onNodeMouseUpForConnection(e, node.id), onDragStart: (e) => e.preventDefault(), style: {
            left: posX,
            top: posY,
            transform: 'translate(-50%, -50%)',
            cursor: isRoot ? 'default' : (draggingNodeId === node.id ? 'grabbing' : 'grab'),
            transition: draggingNodeId === node.id ? 'none' : 'all 0.2s',
            zIndex: isRoot ? 50 : (draggingNodeId === node.id ? 100 : (isSelected ? 10 : 1))
        }, children: isBlackboardVariable ? ((() => {
            const varName = node.data.variableName;
            const currentValue = blackboardVariables[varName];
            const initialValue = initialBlackboardVariables[varName];
            const isModified = isExecuting && JSON.stringify(currentValue) !== JSON.stringify(initialValue);
            return (_jsxs(_Fragment, { children: [_jsxs("div", { className: "bt-node-header blackboard", children: [_jsx(Database, { size: 16, className: "bt-node-header-icon" }), _jsx("div", { className: "bt-node-header-title", children: varName || 'Variable' }), isModified && (_jsx("span", { style: {
                                    fontSize: '9px',
                                    color: '#ffbb00',
                                    backgroundColor: 'rgba(255, 187, 0, 0.2)',
                                    padding: '2px 4px',
                                    borderRadius: '2px',
                                    marginLeft: '4px'
                                }, children: "\u8FD0\u884C\u65F6" }))] }), _jsx("div", { className: "bt-node-body", children: _jsx("div", { className: "bt-node-blackboard-value", style: {
                                backgroundColor: isModified ? 'rgba(255, 187, 0, 0.15)' : 'transparent',
                                border: isModified ? '1px solid rgba(255, 187, 0, 0.3)' : 'none',
                                borderRadius: '2px',
                                padding: '2px 4px'
                            }, title: isModified ? `初始值: ${JSON.stringify(initialValue)}\n当前值: ${JSON.stringify(currentValue)}` : undefined, children: JSON.stringify(currentValue) }) }), _jsx("div", { "data-port": "true", "data-node-id": node.id, "data-port-type": "variable-output", onMouseDown: (e) => onPortMouseDown(e, node.id, '__value__'), onMouseUp: (e) => onPortMouseUp(e, node.id, '__value__'), className: "bt-node-port bt-node-port-variable-output", title: "Output" })] }));
        })()) : (_jsxs(_Fragment, { children: [_jsxs("div", { className: `bt-node-header ${isRoot ? 'root' : (node.template.type || 'action')}`, children: [isRoot ? (_jsx(TreePine, { size: 16, className: "bt-node-header-icon" })) : (node.template.icon && (() => {
                            const IconComponent = iconMap[node.template.icon];
                            return IconComponent ? (_jsx(IconComponent, { size: 16, className: "bt-node-header-icon" })) : (_jsx("span", { className: "bt-node-header-icon", children: node.template.icon }));
                        })()), _jsxs("div", { className: "bt-node-header-title", children: [_jsx("div", { children: isRoot ? 'ROOT' : node.template.displayName }), _jsxs("div", { className: "bt-node-id", title: node.id, children: ["#", node.id] })] }), executionOrder !== undefined && (_jsx("div", { className: "bt-node-execution-order", style: {
                                marginLeft: 'auto',
                                backgroundColor: '#2196f3',
                                color: '#fff',
                                borderRadius: '50%',
                                width: '20px',
                                height: '20px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                fontSize: '11px',
                                fontWeight: 'bold',
                                flexShrink: 0
                            }, title: `执行顺序: ${executionOrder}`, children: executionOrder })), !isRoot && node.template.className && executorRef.current && !executorRef.current.hasExecutor(node.template.className) && (_jsxs("div", { className: "bt-node-missing-executor-warning", style: {
                                marginLeft: executionOrder !== undefined ? '4px' : 'auto',
                                display: 'flex',
                                alignItems: 'center',
                                cursor: 'help',
                                pointerEvents: 'auto',
                                position: 'relative'
                            }, onClick: (e) => e.stopPropagation(), children: [_jsx(AlertCircle, { size: 14, style: {
                                        color: '#f44336',
                                        flexShrink: 0
                                    } }), _jsxs("div", { className: "bt-node-missing-executor-tooltip", children: ["\u7F3A\u5931\u6267\u884C\u5668\uFF1A\u627E\u4E0D\u5230\u8282\u70B9\u5BF9\u5E94\u7684\u6267\u884C\u5668 \"", node.template.className, "\""] })] })), isUncommitted && (_jsxs("div", { className: "bt-node-uncommitted-warning", style: {
                                marginLeft: (executionOrder !== undefined || (!isRoot && node.template.className && executorRef.current && !executorRef.current.hasExecutor(node.template.className))) ? '4px' : 'auto',
                                display: 'flex',
                                alignItems: 'center',
                                cursor: 'help',
                                pointerEvents: 'auto',
                                position: 'relative'
                            }, onClick: (e) => e.stopPropagation(), children: [_jsx(AlertTriangle, { size: 14, style: {
                                        color: '#ff5722',
                                        flexShrink: 0
                                    } }), _jsx("div", { className: "bt-node-uncommitted-tooltip", children: "\u672A\u751F\u6548\u8282\u70B9\uFF1A\u8FD0\u884C\u65F6\u6DFB\u52A0\u7684\u8282\u70B9\uFF0C\u9700\u91CD\u65B0\u8FD0\u884C\u624D\u80FD\u751F\u6548" })] })), !isRoot && !isUncommitted && node.template.type === 'composite' &&
                            (node.template.requiresChildren === undefined || node.template.requiresChildren === true) &&
                            !nodes.some((n) => connections.some((c) => c.from === node.id && c.to === n.id)) && (_jsxs("div", { className: "bt-node-empty-warning-container", style: {
                                marginLeft: (executionOrder !== undefined || (!isRoot && node.template.className && executorRef.current && !executorRef.current.hasExecutor(node.template.className)) || isUncommitted) ? '4px' : 'auto',
                                display: 'flex',
                                alignItems: 'center',
                                cursor: 'help',
                                pointerEvents: 'auto',
                                position: 'relative'
                            }, onClick: (e) => e.stopPropagation(), children: [_jsx(AlertTriangle, { size: 14, style: {
                                        color: '#ff9800',
                                        flexShrink: 0
                                    } }), _jsx("div", { className: "bt-node-empty-warning-tooltip", children: "\u7A7A\u8282\u70B9\uFF1A\u6CA1\u6709\u5B50\u8282\u70B9\uFF0C\u6267\u884C\u65F6\u4F1A\u76F4\u63A5\u8DF3\u8FC7" })] }))] }), _jsxs("div", { className: "bt-node-body", children: [!isRoot && (_jsx("div", { className: "bt-node-category", children: node.template.category })), node.template.properties.length > 0 && (_jsx("div", { className: "bt-node-properties", children: node.template.properties.map((prop, idx) => {
                                const hasConnection = connections.some((conn) => conn.toProperty === prop.name && conn.to === node.id);
                                const propValue = node.data[prop.name];
                                return (_jsxs("div", { className: "bt-node-property", children: [_jsx("div", { "data-port": "true", "data-node-id": node.id, "data-property": prop.name, "data-port-type": "property-input", onMouseDown: (e) => onPortMouseDown(e, node.id, prop.name), onMouseUp: (e) => onPortMouseUp(e, node.id, prop.name), className: `bt-node-port bt-node-port-property ${hasConnection ? 'connected' : ''}`, title: prop.description || prop.name }), _jsxs("span", { className: "bt-node-property-label", title: prop.description, children: [prop.name, ":"] }), propValue !== undefined && (_jsx("span", { className: "bt-node-property-value", children: String(propValue) }))] }, idx));
                            }) }))] }), !isRoot && (_jsx("div", { "data-port": "true", "data-node-id": node.id, "data-port-type": "node-input", onMouseDown: (e) => onPortMouseDown(e, node.id), onMouseUp: (e) => onPortMouseUp(e, node.id), className: "bt-node-port bt-node-port-input", title: "Input" })), (isRoot || node.template.type === 'composite' || node.template.type === 'decorator') &&
                    (node.template.requiresChildren === undefined || node.template.requiresChildren === true) && (_jsx("div", { "data-port": "true", "data-node-id": node.id, "data-port-type": "node-output", onMouseDown: (e) => onPortMouseDown(e, node.id), onMouseUp: (e) => onPortMouseUp(e, node.id), className: "bt-node-port bt-node-port-output", title: "Output" }))] })) }, node.id));
};
//# sourceMappingURL=BehaviorTreeNode.js.map