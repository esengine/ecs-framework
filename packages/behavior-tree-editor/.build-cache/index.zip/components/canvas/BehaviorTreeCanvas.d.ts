import React from 'react';
import { EditorConfig } from '../../types';
/**
 * 画布组件属性
 */
interface BehaviorTreeCanvasProps {
    /**
     * 编辑器配置
     */
    config: EditorConfig;
    /**
     * 子组件
     */
    children: React.ReactNode;
    /**
     * 画布点击事件
     */
    onClick?: (e: React.MouseEvent) => void;
    /**
     * 画布双击事件
     */
    onDoubleClick?: (e: React.MouseEvent) => void;
    /**
     * 画布右键事件
     */
    onContextMenu?: (e: React.MouseEvent) => void;
    /**
     * 鼠标移动事件
     */
    onMouseMove?: (e: React.MouseEvent) => void;
    /**
     * 鼠标按下事件
     */
    onMouseDown?: (e: React.MouseEvent) => void;
    /**
     * 鼠标抬起事件
     */
    onMouseUp?: (e: React.MouseEvent) => void;
    /**
     * 鼠标离开事件
     */
    onMouseLeave?: (e: React.MouseEvent) => void;
    /**
     * 拖放事件
     */
    onDrop?: (e: React.DragEvent) => void;
    /**
     * 拖动悬停事件
     */
    onDragOver?: (e: React.DragEvent) => void;
    /**
     * 拖动进入事件
     */
    onDragEnter?: (e: React.DragEvent) => void;
    /**
     * 拖动离开事件
     */
    onDragLeave?: (e: React.DragEvent) => void;
}
/**
 * 行为树画布组件
 * 负责画布的渲染、缩放、平移等基础功能
 */
export declare const BehaviorTreeCanvas: React.ForwardRefExoticComponent<BehaviorTreeCanvasProps & React.RefAttributes<HTMLDivElement>>;
export {};
//# sourceMappingURL=BehaviorTreeCanvas.d.ts.map