import React from 'react';
import { Node } from '../../domain/models/Node';
import { Connection } from '../../domain/models/Connection';
/**
 * 连线层属性
 */
interface ConnectionLayerProps {
    /**
     * 所有连接
     */
    connections: Connection[];
    /**
     * 所有节点（用于查找位置）
     */
    nodes: Node[];
    /**
     * 选中的连接
     */
    selectedConnection?: {
        from: string;
        to: string;
    } | null;
    /**
     * 获取端口位置的函数
     */
    getPortPosition: (nodeId: string, propertyName?: string, portType?: 'input' | 'output') => {
        x: number;
        y: number;
    } | null;
    /**
     * 连线点击事件
     */
    onConnectionClick?: (e: React.MouseEvent, fromId: string, toId: string) => void;
    /**
     * 连线右键事件
     */
    onConnectionContextMenu?: (e: React.MouseEvent, fromId: string, toId: string) => void;
}
/**
 * 连线层
 * 管理所有连线的渲染
 */
export declare const ConnectionLayer: React.FC<ConnectionLayerProps>;
export {};
//# sourceMappingURL=ConnectionLayer.d.ts.map