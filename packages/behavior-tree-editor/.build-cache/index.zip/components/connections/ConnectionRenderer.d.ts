import React from 'react';
import { ConnectionViewData } from '../../types';
import { Node } from '../../domain/models/Node';
/**
 * 连线渲染器属性
 */
interface ConnectionRendererProps {
    /**
     * 连接视图数据
     */
    connectionData: ConnectionViewData;
    /**
     * 源节点
     */
    fromNode: Node;
    /**
     * 目标节点
     */
    toNode: Node;
    /**
     * 获取端口位置的函数
     */
    getPortPosition: (nodeId: string, propertyName?: string, portType?: 'input' | 'output') => {
        x: number;
        y: number;
    } | null;
    /**
     * 连线点击事件
     */
    onClick?: (e: React.MouseEvent, fromId: string, toId: string) => void;
    /**
     * 连线右键事件
     */
    onContextMenu?: (e: React.MouseEvent, fromId: string, toId: string) => void;
}
/**
 * 连线渲染器
 * 使用贝塞尔曲线渲染节点间的连接
 */
export declare const ConnectionRenderer: React.FC<ConnectionRendererProps>;
export {};
//# sourceMappingURL=ConnectionRenderer.d.ts.map