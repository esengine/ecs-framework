export {};
//# sourceMappingURL=IValidator.js.map