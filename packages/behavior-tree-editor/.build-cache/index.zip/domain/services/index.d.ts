export { TreeValidator } from './TreeValidator';
//# sourceMappingURL=index.d.ts.map