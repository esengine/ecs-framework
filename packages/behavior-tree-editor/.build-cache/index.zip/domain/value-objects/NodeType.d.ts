/**
 * 节点类型值对象
 * 封装节点类型的业务逻辑
 */
export declare class NodeType {
    private readonly _value;
    private constructor();
    get value(): string;
    /**
     * 是否为根节点
     */
    isRoot(): boolean;
    /**
     * 是否为组合节点（可以有多个子节点）
     */
    isComposite(): boolean;
    /**
     * 是否为装饰节点（只能有一个子节点）
     */
    isDecorator(): boolean;
    /**
     * 是否为叶子节点（不能有子节点）
     */
    isLeaf(): boolean;
    /**
     * 获取允许的最大子节点数
     * @returns 0 表示叶子节点，1 表示装饰节点，Infinity 表示组合节点
     */
    getMaxChildren(): number;
    /**
     * 值对象相等性比较
     */
    equals(other: NodeType): boolean;
    toString(): string;
    /**
     * 预定义的节点类型
     */
    static readonly ROOT: NodeType;
    static readonly SEQUENCE: NodeType;
    static readonly SELECTOR: NodeType;
    static readonly PARALLEL: NodeType;
    static readonly REPEATER: NodeType;
    static readonly INVERTER: NodeType;
    static readonly SUCCEEDER: NodeType;
    static readonly FAILER: NodeType;
    static readonly UNTIL_FAIL: NodeType;
    static readonly UNTIL_SUCCESS: NodeType;
    /**
     * 从字符串创建节点类型
     */
    static fromString(value: string): NodeType;
}
//# sourceMappingURL=NodeType.d.ts.map