/**
 * 尺寸值对象
 * 表示宽度和高度
 */
export class Size {
    constructor(width, height) {
        if (width < 0 || height < 0) {
            throw new Error('Size dimensions must be non-negative');
        }
        this._width = width;
        this._height = height;
    }
    get width() {
        return this._width;
    }
    get height() {
        return this._height;
    }
    /**
     * 获取面积
     */
    get area() {
        return this._width * this._height;
    }
    /**
     * 缩放尺寸
     */
    scale(factor) {
        return new Size(this._width * factor, this._height * factor);
    }
    /**
     * 值对象相等性比较
     */
    equals(other) {
        return this._width === other._width && this._height === other._height;
    }
    /**
     * 转换为普通对象
     */
    toObject() {
        return { width: this._width, height: this._height };
    }
    /**
     * 从普通对象创建
     */
    static fromObject(obj) {
        return new Size(obj.width, obj.height);
    }
}
//# sourceMappingURL=Size.js.map