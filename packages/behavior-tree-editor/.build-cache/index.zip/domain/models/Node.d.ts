import { NodeTemplate } from '@esengine/behavior-tree';
import { Position, NodeType } from '../value-objects';
/**
 * 行为树节点领域实体
 * 封装节点的业务逻辑和验证规则
 */
export declare class Node {
    private readonly _id;
    private readonly _template;
    private _data;
    private _position;
    private _children;
    private readonly _nodeType;
    constructor(id: string, template: NodeTemplate, data: Record<string, unknown>, position: Position, children?: string[]);
    get id(): string;
    get template(): NodeTemplate;
    get data(): Record<string, unknown>;
    get position(): Position;
    get children(): ReadonlyArray<string>;
    get nodeType(): NodeType;
    /**
     * 更新节点位置
     */
    moveToPosition(newPosition: Position): Node;
    /**
     * 更新节点数据
     */
    updateData(data: Record<string, unknown>): Node;
    /**
     * 添加子节点
     * @throws ValidationError 如果违反业务规则
     */
    addChild(childId: string): Node;
    /**
     * 移除子节点
     */
    removeChild(childId: string): Node;
    /**
     * 检查是否可以添加子节点
     */
    canAddChild(): boolean;
    /**
     * 检查是否有子节点
     */
    hasChildren(): boolean;
    /**
     * 检查是否为根节点
     */
    isRoot(): boolean;
    /**
     * 转换为普通对象（用于序列化）
     */
    toObject(): {
        id: string;
        template: NodeTemplate;
        data: Record<string, unknown>;
        position: {
            x: number;
            y: number;
        };
        children: string[];
    };
    /**
     * 从普通对象创建节点
     */
    static fromObject(obj: {
        id: string;
        template: NodeTemplate;
        data: Record<string, unknown>;
        position: {
            x: number;
            y: number;
        };
        children: string[];
    }): Node;
}
//# sourceMappingURL=Node.d.ts.map