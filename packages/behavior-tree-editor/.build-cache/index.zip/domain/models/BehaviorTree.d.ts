import { Node } from './Node';
import { Connection } from './Connection';
import { Blackboard } from './Blackboard';
/**
 * 行为树聚合根
 * 管理整个行为树的节点、连接和黑板
 */
export declare class BehaviorTree {
    private readonly _nodes;
    private readonly _connections;
    private readonly _blackboard;
    private readonly _rootNodeId;
    constructor(nodes?: Node[], connections?: Connection[], blackboard?: Blackboard, rootNodeId?: string | null);
    get nodes(): ReadonlyArray<Node>;
    get connections(): ReadonlyArray<Connection>;
    get blackboard(): Blackboard;
    get rootNodeId(): string | null;
    /**
     * 获取指定节点
     */
    getNode(nodeId: string): Node;
    /**
     * 检查节点是否存在
     */
    hasNode(nodeId: string): boolean;
    /**
     * 添加节点
     */
    addNode(node: Node): BehaviorTree;
    /**
     * 移除节点
     * 会同时移除相关的连接
     */
    removeNode(nodeId: string): BehaviorTree;
    /**
     * 更新节点
     */
    updateNode(nodeId: string, updater: (node: Node) => Node): BehaviorTree;
    /**
     * 添加连接
     * 会验证连接的合法性
     */
    addConnection(connection: Connection): BehaviorTree;
    /**
     * 移除连接
     */
    removeConnection(from: string, to: string, fromProperty?: string, toProperty?: string): BehaviorTree;
    /**
     * 检查是否存在连接
     */
    hasConnection(from: string, to: string): boolean;
    /**
     * 检查是否会创建循环引用
     */
    private wouldCreateCycle;
    /**
     * 更新黑板
     */
    updateBlackboard(updater: (blackboard: Blackboard) => Blackboard): BehaviorTree;
    /**
     * 获取节点的子节点
     */
    getChildren(nodeId: string): Node[];
    /**
     * 获取节点的父节点
     */
    getParent(nodeId: string): Node | null;
    /**
     * 验证树的完整性
     */
    private validateTree;
    /**
     * 转换为普通对象
     */
    toObject(): {
        nodes: ReturnType<Node['toObject']>[];
        connections: ReturnType<Connection['toObject']>[];
        blackboard: Record<string, unknown>;
        rootNodeId: string | null;
    };
    /**
     * 从普通对象创建行为树
     */
    static fromObject(obj: {
        nodes: Parameters<typeof Node.fromObject>[0][];
        connections: Parameters<typeof Connection.fromObject>[0][];
        blackboard: Record<string, unknown>;
        rootNodeId: string | null;
    }): BehaviorTree;
    /**
     * 创建空行为树
     */
    static empty(): BehaviorTree;
}
//# sourceMappingURL=BehaviorTree.d.ts.map