/**
 * 黑板领域实体
 * 管理行为树的全局变量
 */
export class Blackboard {
    constructor(variables = {}) {
        this._variables = new Map(Object.entries(variables));
    }
    /**
     * 获取变量值
     */
    get(key) {
        return this._variables.get(key);
    }
    /**
     * 设置变量值
     */
    set(key, value) {
        const newVariables = new Map(this._variables);
        newVariables.set(key, value);
        return new Blackboard(Object.fromEntries(newVariables));
    }
    /**
     * 设置变量值（别名方法）
     */
    setValue(key, value) {
        this._variables.set(key, value);
    }
    /**
     * 删除变量
     */
    delete(key) {
        const newVariables = new Map(this._variables);
        newVariables.delete(key);
        return new Blackboard(Object.fromEntries(newVariables));
    }
    /**
     * 检查变量是否存在
     */
    has(key) {
        return this._variables.has(key);
    }
    /**
     * 获取所有变量名
     */
    keys() {
        return Array.from(this._variables.keys());
    }
    /**
     * 获取所有变量
     */
    getAll() {
        return Object.fromEntries(this._variables);
    }
    /**
     * 批量设置变量
     */
    setAll(variables) {
        const newVariables = new Map(this._variables);
        Object.entries(variables).forEach(([key, value]) => {
            newVariables.set(key, value);
        });
        return new Blackboard(Object.fromEntries(newVariables));
    }
    /**
     * 清空所有变量
     */
    clear() {
        return new Blackboard();
    }
    /**
     * 获取变量数量
     */
    size() {
        return this._variables.size;
    }
    /**
     * 克隆黑板
     */
    clone() {
        return new Blackboard(this.getAll());
    }
    /**
     * 转换为普通对象
     */
    toObject() {
        return this.getAll();
    }
    /**
     * 从普通对象创建黑板
     */
    static fromObject(obj) {
        return new Blackboard(obj);
    }
    /**
     * 创建空黑板
     */
    static empty() {
        return new Blackboard();
    }
}
//# sourceMappingURL=Blackboard.js.map