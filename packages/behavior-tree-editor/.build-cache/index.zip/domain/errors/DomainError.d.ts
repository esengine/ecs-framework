/**
 * 领域错误基类
 */
export declare abstract class DomainError extends Error {
    constructor(message: string);
}
//# sourceMappingURL=DomainError.d.ts.map