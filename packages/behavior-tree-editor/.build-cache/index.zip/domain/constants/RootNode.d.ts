import { Node } from '../models/Node';
import { NodeTemplate } from '@esengine/behavior-tree';
export declare const ROOT_NODE_ID = "root-node";
export declare const createRootNodeTemplate: () => NodeTemplate;
export declare const createRootNode: () => Node;
//# sourceMappingURL=RootNode.d.ts.map