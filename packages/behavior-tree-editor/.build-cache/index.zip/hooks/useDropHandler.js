import { useState } from 'react';
import { NodeType } from '@esengine/behavior-tree';
import { Position } from '../domain/value-objects/Position';
export function useDropHandler(params) {
    const { canvasRef, canvasOffset, canvasScale, nodeOperations, onNodeCreate, isDraggingNode } = params;
    const [isDragging, setIsDragging] = useState(false);
    const handleDrop = (e) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
        // 如果正在移动节点，不处理drop事件
        if (isDraggingNode) {
            return;
        }
        // 检查是否有有效的拖拽数据
        const hasBlackboardData = e.dataTransfer.types.includes('application/blackboard-variable');
        const hasNodeTemplateData = e.dataTransfer.types.includes('application/behavior-tree-node');
        // 如果没有任何有效的拖拽数据，直接返回（避免解析空数据）
        if (!hasBlackboardData && !hasNodeTemplateData) {
            return;
        }
        try {
            const rect = canvasRef.current?.getBoundingClientRect();
            if (!rect)
                return;
            const position = {
                x: (e.clientX - rect.left - canvasOffset.x) / canvasScale,
                y: (e.clientY - rect.top - canvasOffset.y) / canvasScale
            };
            const blackboardVariableData = e.dataTransfer.getData('application/blackboard-variable');
            if (blackboardVariableData) {
                const variableData = JSON.parse(blackboardVariableData);
                const variableTemplate = {
                    type: NodeType.Action,
                    displayName: variableData.variableName,
                    category: 'Blackboard Variable',
                    icon: 'Database',
                    description: `Blackboard variable: ${variableData.variableName}`,
                    color: '#9c27b0',
                    defaultConfig: {
                        nodeType: 'blackboard-variable',
                        variableName: variableData.variableName
                    },
                    properties: [
                        {
                            name: 'variableName',
                            label: '变量名',
                            type: 'variable',
                            defaultValue: variableData.variableName,
                            description: '黑板变量的名称',
                            required: true
                        }
                    ]
                };
                nodeOperations.createNode(variableTemplate, new Position(position.x, position.y), {
                    nodeType: 'blackboard-variable',
                    variableName: variableData.variableName
                });
                return;
            }
            let templateData = e.dataTransfer.getData('application/behavior-tree-node');
            if (!templateData) {
                templateData = e.dataTransfer.getData('text/plain');
            }
            if (!templateData) {
                return;
            }
            const template = JSON.parse(templateData);
            nodeOperations.createNode(template, new Position(position.x, position.y), template.defaultConfig);
            onNodeCreate?.(template, position);
        }
        catch (error) {
            console.error('Failed to create node:', error);
        }
    };
    const handleDragOver = (e) => {
        e.preventDefault();
        e.stopPropagation();
        e.dataTransfer.dropEffect = 'copy';
        if (!isDragging) {
            setIsDragging(true);
        }
    };
    const handleDragLeave = (e) => {
        if (e.currentTarget === e.target) {
            setIsDragging(false);
        }
    };
    const handleDragEnter = (e) => {
        e.preventDefault();
    };
    return {
        isDragging,
        handleDrop,
        handleDragOver,
        handleDragLeave,
        handleDragEnter
    };
}
//# sourceMappingURL=useDropHandler.js.map