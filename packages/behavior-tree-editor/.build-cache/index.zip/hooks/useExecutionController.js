import { useState, useEffect, useMemo } from 'react';
import { ExecutionController } from '../application/services/ExecutionController';
import { BlackboardManager } from '../application/services/BlackboardManager';
import { useExecutionStore } from '../stores';
export function useExecutionController(params) {
    const { rootNodeId, projectPath, blackboardVariables, nodes, connections, onBlackboardUpdate, onInitialBlackboardSave, onExecutingChange, onSaveNodesDataSnapshot, onRestoreNodesData } = params;
    const [executionMode, setExecutionMode] = useState('idle');
    const [executionLogs, setExecutionLogs] = useState([]);
    const [executionSpeed, setExecutionSpeed] = useState(1.0);
    const [tickCount, setTickCount] = useState(0);
    const controller = useMemo(() => {
        return new ExecutionController({
            rootNodeId,
            projectPath,
            onLogsUpdate: setExecutionLogs,
            onBlackboardUpdate,
            onTickCountUpdate: setTickCount,
            onExecutionStatusUpdate: (statuses, orders) => {
                const store = useExecutionStore.getState();
                store.updateNodeExecutionStatuses(statuses, orders);
            }
        });
    }, [rootNodeId, projectPath, onBlackboardUpdate]);
    const blackboardManager = useMemo(() => new BlackboardManager(), []);
    useEffect(() => {
        return () => {
            controller.destroy();
        };
    }, [controller]);
    useEffect(() => {
        controller.setConnections(connections);
    }, [connections, controller]);
    useEffect(() => {
        if (executionMode === 'idle')
            return;
        const executorVars = controller.getBlackboardVariables();
        Object.entries(blackboardVariables).forEach(([key, value]) => {
            if (executorVars[key] !== value) {
                controller.updateBlackboardVariable(key, value);
            }
        });
    }, [blackboardVariables, executionMode, controller]);
    useEffect(() => {
        if (executionMode === 'idle')
            return;
        controller.updateNodes(nodes);
    }, [nodes, executionMode, controller]);
    const handlePlay = async () => {
        try {
            blackboardManager.setInitialVariables(blackboardVariables);
            blackboardManager.setCurrentVariables(blackboardVariables);
            onInitialBlackboardSave(blackboardManager.getInitialVariables());
            onSaveNodesDataSnapshot();
            onExecutingChange(true);
            setExecutionMode('running');
            await controller.play(nodes, blackboardVariables, connections);
        }
        catch (error) {
            console.error('Failed to start execution:', error);
            setExecutionMode('idle');
            onExecutingChange(false);
        }
    };
    const handlePause = async () => {
        try {
            await controller.pause();
            const newMode = controller.getMode();
            setExecutionMode(newMode);
        }
        catch (error) {
            console.error('Failed to pause/resume execution:', error);
        }
    };
    const handleStop = async () => {
        try {
            await controller.stop();
            setExecutionMode('idle');
            setTickCount(0);
            const restoredVars = blackboardManager.restoreInitialVariables();
            onBlackboardUpdate(restoredVars);
            onRestoreNodesData();
            useExecutionStore.getState().clearNodeExecutionStatuses();
            onExecutingChange(false);
        }
        catch (error) {
            console.error('Failed to stop execution:', error);
        }
    };
    const handleStep = () => {
        controller.step();
        setExecutionMode('step');
    };
    const handleReset = async () => {
        try {
            await controller.reset();
            setExecutionMode('idle');
            setTickCount(0);
        }
        catch (error) {
            console.error('Failed to reset execution:', error);
        }
    };
    const handleSpeedChange = (speed) => {
        setExecutionSpeed(speed);
        controller.setSpeed(speed);
    };
    return {
        executionMode,
        executionLogs,
        executionSpeed,
        tickCount,
        handlePlay,
        handlePause,
        handleStop,
        handleStep,
        handleReset,
        handleSpeedChange,
        setExecutionLogs,
        controller,
        blackboardManager
    };
}
//# sourceMappingURL=useExecutionController.js.map