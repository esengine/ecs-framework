import { CommandManager } from '@esengine/editor-core';
/**
 * 撤销/重做功能 Hook
 */
export declare function useCommandHistory(): {
    commandManager: CommandManager;
    canUndo: boolean;
    canRedo: boolean;
    undo: () => void;
    redo: () => void;
    getUndoHistory: () => string[];
    getRedoHistory: () => string[];
    clear: () => void;
};
//# sourceMappingURL=useCommandHistory.d.ts.map