import { useCallback, useMemo } from 'react';
import { useCanvasStore } from '../stores';
/**
 * 画布交互 Hook
 * 封装画布的缩放、平移等交互逻辑
 */
export function useCanvasInteraction() {
    const { offset: canvasOffset, scale: canvasScale, isPanning, panStart, setOffset: setCanvasOffset, setScale: setCanvasScale, setIsPanning, setPanStart, resetView } = useCanvasStore();
    const handleWheel = useCallback((e) => {
        e.preventDefault();
        const delta = e.deltaY;
        const scaleFactor = 1.1;
        if (delta < 0) {
            setCanvasScale(Math.min(canvasScale * scaleFactor, 3));
        }
        else {
            setCanvasScale(Math.max(canvasScale / scaleFactor, 0.1));
        }
    }, [canvasScale, setCanvasScale]);
    const startPanning = useCallback((clientX, clientY) => {
        setIsPanning(true);
        setPanStart({ x: clientX, y: clientY });
    }, [setIsPanning, setPanStart]);
    const updatePanning = useCallback((clientX, clientY) => {
        if (!isPanning)
            return;
        const dx = clientX - panStart.x;
        const dy = clientY - panStart.y;
        setCanvasOffset({
            x: canvasOffset.x + dx,
            y: canvasOffset.y + dy
        });
        setPanStart({ x: clientX, y: clientY });
    }, [isPanning, panStart, canvasOffset, setCanvasOffset, setPanStart]);
    const stopPanning = useCallback(() => {
        setIsPanning(false);
    }, [setIsPanning]);
    const zoomIn = useCallback(() => {
        setCanvasScale(Math.min(canvasScale * 1.2, 3));
    }, [canvasScale, setCanvasScale]);
    const zoomOut = useCallback(() => {
        setCanvasScale(Math.max(canvasScale / 1.2, 0.1));
    }, [canvasScale, setCanvasScale]);
    const zoomToFit = useCallback(() => {
        resetView();
    }, [resetView]);
    const screenToCanvas = useCallback((screenX, screenY) => {
        return {
            x: (screenX - canvasOffset.x) / canvasScale,
            y: (screenY - canvasOffset.y) / canvasScale
        };
    }, [canvasOffset, canvasScale]);
    const canvasToScreen = useCallback((canvasX, canvasY) => {
        return {
            x: canvasX * canvasScale + canvasOffset.x,
            y: canvasY * canvasScale + canvasOffset.y
        };
    }, [canvasOffset, canvasScale]);
    return useMemo(() => ({
        canvasOffset,
        canvasScale,
        isPanning,
        handleWheel,
        startPanning,
        updatePanning,
        stopPanning,
        zoomIn,
        zoomOut,
        zoomToFit,
        screenToCanvas,
        canvasToScreen
    }), [
        canvasOffset,
        canvasScale,
        isPanning,
        handleWheel,
        startPanning,
        updatePanning,
        stopPanning,
        zoomIn,
        zoomOut,
        zoomToFit,
        screenToCanvas,
        canvasToScreen
    ]);
}
//# sourceMappingURL=useCanvasInteraction.js.map