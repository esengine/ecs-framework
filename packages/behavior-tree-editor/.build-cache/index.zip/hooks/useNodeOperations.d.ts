import { NodeTemplate } from '@esengine/behavior-tree';
import { CommandManager } from '@esengine/editor-core';
import { Position } from '../domain/value-objects/Position';
import { INodeFactory } from '../domain/interfaces/INodeFactory';
import { IValidator } from '../domain/interfaces/IValidator';
/**
 * 节点操作 Hook
 */
export declare function useNodeOperations(nodeFactory: INodeFactory, validator: IValidator, commandManager: CommandManager): {
    createNode: (template: NodeTemplate, position: Position, data?: Record<string, unknown>) => import("..").Node;
    createNodeByType: (nodeType: string, position: Position, data?: Record<string, unknown>) => import("..").Node;
    deleteNode: (nodeId: string) => void;
    deleteNodes: (nodeIds: string[]) => void;
    moveNode: (nodeId: string, position: Position) => void;
    moveNodes: (moves: Array<{
        nodeId: string;
        position: Position;
    }>) => void;
    updateNodeData: (nodeId: string, data: Record<string, unknown>) => void;
};
//# sourceMappingURL=useNodeOperations.d.ts.map