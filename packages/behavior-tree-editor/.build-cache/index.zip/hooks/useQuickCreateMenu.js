import { useState } from 'react';
import { Node } from '../domain/models/Node';
import { Position } from '../domain/value-objects/Position';
export function useQuickCreateMenu(params) {
    const { nodeOperations, connectionOperations, canvasRef, canvasOffset, canvasScale, connectingFrom, connectingFromProperty, clearConnecting, nodes, setNodes, connections, executionMode, onStop, onNodeCreate, showToast } = params;
    const [quickCreateMenu, setQuickCreateMenu] = useState({
        visible: false,
        position: { x: 0, y: 0 },
        searchText: '',
        selectedIndex: 0,
        mode: 'create',
        replaceNodeId: null
    });
    const handleReplaceNode = (newTemplate) => {
        const nodeToReplace = nodes.find((n) => n.id === quickCreateMenu.replaceNodeId);
        if (!nodeToReplace)
            return;
        if (executionMode !== 'idle') {
            onStop();
        }
        const newData = { ...newTemplate.defaultConfig };
        const newPropertyNames = new Set(newTemplate.properties.map((p) => p.name));
        for (const [key, value] of Object.entries(nodeToReplace.data)) {
            if (key === 'nodeType' || key === 'compositeType' || key === 'decoratorType' ||
                key === 'actionType' || key === 'conditionType') {
                continue;
            }
            if (newPropertyNames.has(key)) {
                newData[key] = value;
            }
        }
        const newNode = new Node(nodeToReplace.id, newTemplate, newData, nodeToReplace.position, Array.from(nodeToReplace.children));
        setNodes(nodes.map((n) => n.id === newNode.id ? newNode : n));
        const propertyConnections = connections.filter((conn) => conn.connectionType === 'property' && conn.to === newNode.id);
        propertyConnections.forEach((conn) => {
            connectionOperations.removeConnection(conn.from, conn.to, conn.fromProperty, conn.toProperty);
        });
        closeQuickCreateMenu();
        showToast?.(`已将节点替换为 ${newTemplate.displayName}`, 'success');
    };
    const handleQuickCreateNode = (template) => {
        if (quickCreateMenu.mode === 'replace') {
            handleReplaceNode(template);
            return;
        }
        const rect = canvasRef.current?.getBoundingClientRect();
        if (!rect) {
            return;
        }
        const posX = (quickCreateMenu.position.x - rect.left - canvasOffset.x) / canvasScale;
        const posY = (quickCreateMenu.position.y - rect.top - canvasOffset.y) / canvasScale;
        const newNode = nodeOperations.createNode(template, new Position(posX, posY), template.defaultConfig);
        if (connectingFrom) {
            const fromNode = nodes.find((n) => n.id === connectingFrom);
            if (fromNode) {
                if (connectingFromProperty) {
                    connectionOperations.addConnection(connectingFrom, newNode.id, 'property', connectingFromProperty, undefined);
                }
                else {
                    connectionOperations.addConnection(connectingFrom, newNode.id, 'node');
                }
            }
        }
        closeQuickCreateMenu();
        onNodeCreate?.(template, { x: posX, y: posY });
    };
    const openQuickCreateMenu = (position, mode, replaceNodeId) => {
        setQuickCreateMenu({
            visible: true,
            position,
            searchText: '',
            selectedIndex: 0,
            mode,
            replaceNodeId: replaceNodeId || null
        });
    };
    const closeQuickCreateMenu = () => {
        setQuickCreateMenu({
            visible: false,
            position: { x: 0, y: 0 },
            searchText: '',
            selectedIndex: 0,
            mode: 'create',
            replaceNodeId: null
        });
        clearConnecting();
    };
    return {
        quickCreateMenu,
        setQuickCreateMenu,
        handleQuickCreateNode,
        handleReplaceNode,
        openQuickCreateMenu,
        closeQuickCreateMenu
    };
}
//# sourceMappingURL=useQuickCreateMenu.js.map