import { RefObject } from 'react';
import { Node as BehaviorTreeNode } from '../domain/models/Node';
import { Connection } from '../domain/models/Connection';
import { useConnectionOperations } from './useConnectionOperations';
interface UsePortConnectionParams {
    canvasRef: RefObject<HTMLDivElement>;
    canvasOffset: {
        x: number;
        y: number;
    };
    canvasScale: number;
    nodes: BehaviorTreeNode[];
    connections: Connection[];
    connectingFrom: string | null;
    connectingFromProperty: string | null;
    connectionOperations: ReturnType<typeof useConnectionOperations>;
    setConnectingFrom: (nodeId: string | null) => void;
    setConnectingFromProperty: (propertyName: string | null) => void;
    clearConnecting: () => void;
    sortChildrenByPosition: () => void;
    showToast?: (message: string, type: 'success' | 'error' | 'info' | 'warning') => void;
}
export declare function usePortConnection(params: UsePortConnectionParams): {
    handlePortMouseDown: (e: React.MouseEvent, nodeId: string, propertyName?: string) => void;
    handlePortMouseUp: (e: React.MouseEvent, nodeId: string, propertyName?: string) => void;
    handleNodeMouseUpForConnection: (e: React.MouseEvent, nodeId: string) => void;
};
export {};
//# sourceMappingURL=usePortConnection.d.ts.map