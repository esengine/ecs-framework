import { useState, useEffect, useRef } from 'react';
export function useNodeTracking(params) {
    const { nodes, executionMode } = params;
    const [uncommittedNodeIds, setUncommittedNodeIds] = useState(new Set());
    const activeNodeIdsRef = useRef(new Set());
    useEffect(() => {
        if (executionMode === 'idle') {
            setUncommittedNodeIds(new Set());
            activeNodeIdsRef.current = new Set(nodes.map((n) => n.id));
        }
        else if (executionMode === 'running' || executionMode === 'paused') {
            const currentNodeIds = new Set(nodes.map((n) => n.id));
            const newNodeIds = new Set();
            currentNodeIds.forEach((id) => {
                if (!activeNodeIdsRef.current.has(id)) {
                    newNodeIds.add(id);
                }
            });
            if (newNodeIds.size > 0) {
                setUncommittedNodeIds((prev) => new Set([...prev, ...newNodeIds]));
            }
        }
    }, [nodes, executionMode]);
    return {
        uncommittedNodeIds
    };
}
//# sourceMappingURL=useNodeTracking.js.map