import { RefObject } from 'react';
import { NodeTemplate } from '@esengine/behavior-tree';
import { Node } from '../domain/models/Node';
import { Connection } from '../domain/models/Connection';
import { useNodeOperations } from './useNodeOperations';
import { useConnectionOperations } from './useConnectionOperations';
type BehaviorTreeNode = Node;
interface QuickCreateMenuState {
    visible: boolean;
    position: {
        x: number;
        y: number;
    };
    searchText: string;
    selectedIndex: number;
    mode: 'create' | 'replace';
    replaceNodeId: string | null;
}
type ExecutionMode = 'idle' | 'running' | 'paused' | 'step';
interface UseQuickCreateMenuParams {
    nodeOperations: ReturnType<typeof useNodeOperations>;
    connectionOperations: ReturnType<typeof useConnectionOperations>;
    canvasRef: RefObject<HTMLDivElement>;
    canvasOffset: {
        x: number;
        y: number;
    };
    canvasScale: number;
    connectingFrom: string | null;
    connectingFromProperty: string | null;
    clearConnecting: () => void;
    nodes: BehaviorTreeNode[];
    setNodes: (nodes: BehaviorTreeNode[]) => void;
    connections: Connection[];
    executionMode: ExecutionMode;
    onStop: () => void;
    onNodeCreate?: (template: NodeTemplate, position: {
        x: number;
        y: number;
    }) => void;
    showToast?: (message: string, type: 'success' | 'error' | 'info') => void;
}
export declare function useQuickCreateMenu(params: UseQuickCreateMenuParams): {
    quickCreateMenu: QuickCreateMenuState;
    setQuickCreateMenu: import("react").Dispatch<import("react").SetStateAction<QuickCreateMenuState>>;
    handleQuickCreateNode: (template: NodeTemplate) => void;
    handleReplaceNode: (newTemplate: NodeTemplate) => void;
    openQuickCreateMenu: (position: {
        x: number;
        y: number;
    }, mode: "create" | "replace", replaceNodeId?: string | null) => void;
    closeQuickCreateMenu: () => void;
};
export {};
//# sourceMappingURL=useQuickCreateMenu.d.ts.map