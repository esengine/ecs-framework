import { useState, useRef } from 'react';
import { ROOT_NODE_ID } from '../domain/constants/RootNode';
import { Position } from '../domain/value-objects/Position';
export function useNodeDrag(params) {
    const { canvasRef, canvasOffset, canvasScale, nodes, selectedNodeIds, draggingNodeId, dragStartPositions, isDraggingNode, dragDelta, nodeOperations, setSelectedNodeIds, startDragging, stopDragging, setIsDraggingNode, setDragDelta, setIsBoxSelecting, setBoxSelectStart, setBoxSelectEnd, sortChildrenByPosition } = params;
    const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
    const justFinishedDragRef = useRef(false);
    const handleNodeMouseDown = (e, nodeId) => {
        if (e.button !== 0)
            return;
        if (nodeId === ROOT_NODE_ID)
            return;
        const target = e.target;
        if (target.getAttribute('data-port')) {
            return;
        }
        e.stopPropagation();
        setIsBoxSelecting(false);
        setBoxSelectStart(null);
        setBoxSelectEnd(null);
        const node = nodes.find((n) => n.id === nodeId);
        if (!node)
            return;
        const rect = canvasRef.current?.getBoundingClientRect();
        if (!rect)
            return;
        const canvasX = (e.clientX - rect.left - canvasOffset.x) / canvasScale;
        const canvasY = (e.clientY - rect.top - canvasOffset.y) / canvasScale;
        let nodesToDrag;
        if (selectedNodeIds.includes(nodeId)) {
            nodesToDrag = selectedNodeIds;
        }
        else {
            nodesToDrag = [nodeId];
            setSelectedNodeIds([nodeId]);
        }
        const startPositions = new Map();
        nodesToDrag.forEach((id) => {
            const n = nodes.find((node) => node.id === id);
            if (n) {
                startPositions.set(id, { x: n.position.x, y: n.position.y });
            }
        });
        startDragging(nodeId, startPositions);
        setDragOffset({
            x: canvasX - node.position.x,
            y: canvasY - node.position.y
        });
    };
    const handleNodeMouseMove = (e) => {
        if (!draggingNodeId)
            return;
        if (!isDraggingNode) {
            setIsDraggingNode(true);
        }
        const rect = canvasRef.current?.getBoundingClientRect();
        if (!rect)
            return;
        const canvasX = (e.clientX - rect.left - canvasOffset.x) / canvasScale;
        const canvasY = (e.clientY - rect.top - canvasOffset.y) / canvasScale;
        const newX = canvasX - dragOffset.x;
        const newY = canvasY - dragOffset.y;
        const draggedNodeStartPos = dragStartPositions.get(draggingNodeId);
        if (!draggedNodeStartPos)
            return;
        const deltaX = newX - draggedNodeStartPos.x;
        const deltaY = newY - draggedNodeStartPos.y;
        setDragDelta({ dx: deltaX, dy: deltaY });
    };
    const handleNodeMouseUp = () => {
        if (!draggingNodeId)
            return;
        const hasMoved = dragDelta.dx !== 0 || dragDelta.dy !== 0;
        if (hasMoved) {
            const moves = [];
            dragStartPositions.forEach((startPos, nodeId) => {
                moves.push({
                    nodeId,
                    position: new Position(startPos.x + dragDelta.dx, startPos.y + dragDelta.dy)
                });
            });
            nodeOperations.moveNodes(moves);
            setTimeout(() => {
                sortChildrenByPosition();
            }, 0);
            justFinishedDragRef.current = true;
            setTimeout(() => {
                justFinishedDragRef.current = false;
            }, 0);
        }
        setDragDelta({ dx: 0, dy: 0 });
        stopDragging();
        setIsDraggingNode(false);
    };
    return {
        handleNodeMouseDown,
        handleNodeMouseMove,
        handleNodeMouseUp,
        dragOffset,
        justFinishedDragRef
    };
}
//# sourceMappingURL=useNodeDrag.js.map