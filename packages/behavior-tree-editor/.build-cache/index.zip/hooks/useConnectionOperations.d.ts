import { CommandManager } from '@esengine/editor-core';
import { ConnectionType } from '../domain/models/Connection';
import { IValidator } from '../domain/interfaces/IValidator';
/**
 * 连接操作 Hook
 */
export declare function useConnectionOperations(validator: IValidator, commandManager: CommandManager): {
    addConnection: (from: string, to: string, connectionType?: ConnectionType, fromProperty?: string, toProperty?: string) => import("../domain/models/Connection").Connection;
    removeConnection: (from: string, to: string, fromProperty?: string, toProperty?: string) => void;
};
//# sourceMappingURL=useConnectionOperations.d.ts.map