import { useState } from 'react';
import { ROOT_NODE_ID } from '../domain/constants/RootNode';
export function useContextMenu() {
    const [contextMenu, setContextMenu] = useState({
        visible: false,
        position: { x: 0, y: 0 },
        nodeId: null
    });
    const handleNodeContextMenu = (e, node) => {
        e.preventDefault();
        e.stopPropagation();
        if (node.id === ROOT_NODE_ID) {
            return;
        }
        setContextMenu({
            visible: true,
            position: { x: e.clientX, y: e.clientY },
            nodeId: node.id
        });
    };
    const handleCanvasContextMenu = (e) => {
        e.preventDefault();
        e.stopPropagation();
        setContextMenu({
            visible: true,
            position: { x: e.clientX, y: e.clientY },
            nodeId: null
        });
    };
    const closeContextMenu = () => {
        setContextMenu({ ...contextMenu, visible: false });
    };
    return {
        contextMenu,
        setContextMenu,
        handleNodeContextMenu,
        handleCanvasContextMenu,
        closeContextMenu
    };
}
//# sourceMappingURL=useContextMenu.js.map