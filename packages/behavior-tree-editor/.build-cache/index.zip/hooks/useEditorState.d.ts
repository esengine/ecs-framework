import { BehaviorTreeExecutor } from '../utils/BehaviorTreeExecutor';
export declare function useEditorState(): {
    canvasRef: import("react").RefObject<HTMLDivElement>;
    stopExecutionRef: import("react").MutableRefObject<(() => void) | null>;
    executorRef: import("react").MutableRefObject<BehaviorTreeExecutor | null>;
    selectedConnection: {
        from: string;
        to: string;
    } | null;
    setSelectedConnection: import("react").Dispatch<import("react").SetStateAction<{
        from: string;
        to: string;
    } | null>>;
};
//# sourceMappingURL=useEditorState.d.ts.map