import { ExecutionController, ExecutionMode } from '../application/services/ExecutionController';
import { BlackboardManager } from '../application/services/BlackboardManager';
import { Node as BehaviorTreeNode } from '../domain/models/Node';
import { Connection } from '../domain/models/Connection';
import { ExecutionLog } from '../utils/BehaviorTreeExecutor';
import { BlackboardValue } from '../domain/models/Blackboard';
type BlackboardVariables = Record<string, BlackboardValue>;
interface UseExecutionControllerParams {
    rootNodeId: string;
    projectPath: string | null;
    blackboardVariables: BlackboardVariables;
    nodes: BehaviorTreeNode[];
    connections: Connection[];
    initialBlackboardVariables: BlackboardVariables;
    onBlackboardUpdate: (variables: BlackboardVariables) => void;
    onInitialBlackboardSave: (variables: BlackboardVariables) => void;
    onExecutingChange: (isExecuting: boolean) => void;
    onSaveNodesDataSnapshot: () => void;
    onRestoreNodesData: () => void;
}
export declare function useExecutionController(params: UseExecutionControllerParams): {
    executionMode: ExecutionMode;
    executionLogs: ExecutionLog[];
    executionSpeed: number;
    tickCount: number;
    handlePlay: () => Promise<void>;
    handlePause: () => Promise<void>;
    handleStop: () => Promise<void>;
    handleStep: () => void;
    handleReset: () => Promise<void>;
    handleSpeedChange: (speed: number) => void;
    setExecutionLogs: import("react").Dispatch<import("react").SetStateAction<ExecutionLog[]>>;
    controller: ExecutionController;
    blackboardManager: BlackboardManager;
};
export {};
//# sourceMappingURL=useExecutionController.d.ts.map