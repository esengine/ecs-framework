/**
 * 画布交互 Hook
 * 封装画布的缩放、平移等交互逻辑
 */
export declare function useCanvasInteraction(): {
    canvasOffset: {
        x: number;
        y: number;
    };
    canvasScale: number;
    isPanning: boolean;
    handleWheel: (e: React.WheelEvent) => void;
    startPanning: (clientX: number, clientY: number) => void;
    updatePanning: (clientX: number, clientY: number) => void;
    stopPanning: () => void;
    zoomIn: () => void;
    zoomOut: () => void;
    zoomToFit: () => void;
    screenToCanvas: (screenX: number, screenY: number) => {
        x: number;
        y: number;
    };
    canvasToScreen: (canvasX: number, canvasY: number) => {
        x: number;
        y: number;
    };
};
//# sourceMappingURL=useCanvasInteraction.d.ts.map