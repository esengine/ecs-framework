import { NodeTemplate } from '@esengine/behavior-tree';
import { Node as BehaviorTreeNode } from '../domain/models/Node';
import { LucideIcon } from 'lucide-react';
import React from 'react';
export interface INodeRenderer {
    canRender(node: BehaviorTreeNode): boolean;
    render(node: BehaviorTreeNode, context: NodeRenderContext): React.ReactElement;
}
export interface NodeRenderContext {
    isSelected: boolean;
    isExecuting: boolean;
    onNodeClick: (e: React.MouseEvent, node: BehaviorTreeNode) => void;
    onContextMenu: (e: React.MouseEvent, node: BehaviorTreeNode) => void;
}
export interface IPropertyEditor {
    canEdit(propertyType: string): boolean;
    render(property: PropertyEditorProps): React.ReactElement;
}
export type PropertyValue = string | number | boolean | object | null | undefined;
export interface PropertyEditorProps<T = PropertyValue> {
    propertyName: string;
    propertyType: string;
    value: T;
    onChange: (value: T) => void;
    config?: Record<string, PropertyValue>;
}
export interface INodeProvider {
    getNodeTemplates(): NodeTemplate[];
    getCategory(): string;
    getIcon(): string | LucideIcon;
}
export interface IToolbarButton {
    id: string;
    label: string;
    icon: LucideIcon;
    tooltip?: string;
    onClick: () => void;
    isVisible?: () => boolean;
    isEnabled?: () => boolean;
}
export interface IPanelProvider {
    id: string;
    title: string;
    icon?: LucideIcon;
    render(): React.ReactElement;
    canActivate?(): boolean;
}
export interface IEditorValidator {
    name: string;
    validate(nodes: BehaviorTreeNode[]): EditorValidationResult[];
}
export interface EditorValidationResult {
    severity: 'error' | 'warning' | 'info';
    nodeId?: string;
    message: string;
    code?: string;
}
export interface ICommandProvider {
    getCommandId(): string;
    getCommandName(): string;
    getShortcut?(): string;
    canExecute?(): boolean;
    execute(context: CommandExecutionContext): void | Promise<void>;
}
export interface CommandExecutionContext {
    selectedNodeIds: string[];
    nodes: BehaviorTreeNode[];
    currentFile?: string;
}
export declare class EditorExtensionRegistry {
    private nodeRenderers;
    private propertyEditors;
    private nodeProviders;
    private toolbarButtons;
    private panelProviders;
    private validators;
    private commandProviders;
    registerNodeRenderer(renderer: INodeRenderer): void;
    unregisterNodeRenderer(renderer: INodeRenderer): void;
    getNodeRenderer(node: BehaviorTreeNode): INodeRenderer | undefined;
    registerPropertyEditor(editor: IPropertyEditor): void;
    unregisterPropertyEditor(editor: IPropertyEditor): void;
    getPropertyEditor(propertyType: string): IPropertyEditor | undefined;
    registerNodeProvider(provider: INodeProvider): void;
    unregisterNodeProvider(provider: INodeProvider): void;
    getAllNodeTemplates(): NodeTemplate[];
    registerToolbarButton(button: IToolbarButton): void;
    unregisterToolbarButton(button: IToolbarButton): void;
    getToolbarButtons(): IToolbarButton[];
    registerPanelProvider(provider: IPanelProvider): void;
    unregisterPanelProvider(provider: IPanelProvider): void;
    getPanelProviders(): IPanelProvider[];
    registerValidator(validator: IEditorValidator): void;
    unregisterValidator(validator: IEditorValidator): void;
    validateTree(nodes: BehaviorTreeNode[]): Promise<EditorValidationResult[]>;
    registerCommandProvider(provider: ICommandProvider): void;
    unregisterCommandProvider(provider: ICommandProvider): void;
    getCommandProvider(commandId: string): ICommandProvider | undefined;
    getAllCommandProviders(): ICommandProvider[];
    clear(): void;
}
export declare function getGlobalExtensionRegistry(): EditorExtensionRegistry;
export declare function resetGlobalExtensionRegistry(): void;
//# sourceMappingURL=IEditorExtensions.d.ts.map