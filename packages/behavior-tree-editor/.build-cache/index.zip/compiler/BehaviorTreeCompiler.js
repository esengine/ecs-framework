import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState, useEffect } from 'react';
import { File, FolderTree, FolderOpen } from 'lucide-react';
import { useTreeStore } from '../stores/useTreeStore';
import { GlobalBlackboardTypeGenerator } from '../generators/GlobalBlackboardTypeGenerator';
export class BehaviorTreeCompiler {
    constructor() {
        this.id = 'behavior-tree';
        this.name = '行为树编译器';
        this.description = '将行为树文件编译为运行时资产和TypeScript类型定义';
        this.projectPath = null;
    }
    async compile(options, context) {
        this.projectPath = context.projectPath;
        const fileSystem = context.moduleContext.fileSystem;
        if (!this.projectPath) {
            return {
                success: false,
                message: '错误：没有打开的项目',
                errors: ['请先打开一个项目']
            };
        }
        try {
            const outputFiles = [];
            const errors = [];
            if (options.mode === 'workspace') {
                for (const fileId of options.selectedFiles) {
                    const format = options.fileFormats.get(fileId) || 'binary';
                    const result = await this.compileFile(fileId, options.assetOutputPath, options.typeOutputPath, format, fileSystem);
                    if (result.success) {
                        outputFiles.push(...(result.outputFiles || []));
                    }
                    else {
                        errors.push(`${fileId}: ${result.message}`);
                    }
                }
                const globalTypeResult = await this.generateGlobalBlackboardTypes(options.typeOutputPath, fileSystem);
                if (globalTypeResult.success) {
                    outputFiles.push(...(globalTypeResult.outputFiles || []));
                }
                else {
                    errors.push(globalTypeResult.message);
                }
            }
            else {
                const currentFileName = this.getCurrentFileName();
                if (!currentFileName) {
                    return {
                        success: false,
                        message: '错误：没有打开的行为树文件',
                        errors: ['请先打开一个行为树文件']
                    };
                }
                const format = options.fileFormats.get(currentFileName) || 'binary';
                const result = await this.compileFile(currentFileName, options.assetOutputPath, options.typeOutputPath, format, fileSystem);
                if (result.success) {
                    outputFiles.push(...(result.outputFiles || []));
                }
                else {
                    errors.push(result.message);
                }
            }
            if (errors.length > 0) {
                return {
                    success: false,
                    message: `编译完成，但有 ${errors.length} 个错误`,
                    outputFiles,
                    errors
                };
            }
            return {
                success: true,
                message: `成功编译 ${outputFiles.length} 个文件`,
                outputFiles
            };
        }
        catch (error) {
            return {
                success: false,
                message: `编译失败: ${error}`,
                errors: [String(error)]
            };
        }
    }
    async compileFile(fileId, assetOutputPath, typeOutputPath, format, fileSystem) {
        try {
            const btreePath = `${this.projectPath}/.ecs/behaviors/${fileId}.btree`;
            const fileContent = await fileSystem.readFile(btreePath);
            const treeData = JSON.parse(fileContent);
            const treeStore = useTreeStore.getState();
            const runtimeAsset = treeStore.exportToRuntimeAsset({
                name: fileId,
                description: treeData.metadata?.description || ''
            }, format);
            const extension = format === 'json' ? '.btree.json' : '.btree.bin';
            const assetPath = `${assetOutputPath}/${fileId}${extension}`;
            if (format === 'json') {
                await fileSystem.writeFile(assetPath, runtimeAsset);
            }
            else {
                await fileSystem.writeBinary(assetPath, runtimeAsset);
            }
            const blackboardVars = treeData.blackboard || {};
            const typeContent = this.generateBlackboardTypes(fileId, blackboardVars);
            const typePath = `${typeOutputPath}/${fileId}.d.ts`;
            await fileSystem.writeFile(typePath, typeContent);
            return {
                success: true,
                message: `成功编译 ${fileId}`,
                outputFiles: [assetPath, typePath]
            };
        }
        catch (error) {
            return {
                success: false,
                message: `编译 ${fileId} 失败: ${error}`,
                errors: [String(error)]
            };
        }
    }
    async generateGlobalBlackboardTypes(typeOutputPath, fileSystem) {
        try {
            if (!this.projectPath) {
                throw new Error('No project path');
            }
            const btreeFiles = await fileSystem.scanFiles(`${this.projectPath}/.ecs/behaviors`, '*.btree');
            const variables = [];
            for (const fileId of btreeFiles) {
                const btreePath = `${this.projectPath}/.ecs/behaviors/${fileId}.btree`;
                const fileContent = await fileSystem.readFile(btreePath);
                const treeData = JSON.parse(fileContent);
                const blackboard = treeData.blackboard || {};
                for (const [key, value] of Object.entries(blackboard)) {
                    variables.push({
                        name: key,
                        type: this.inferType(value),
                        defaultValue: value
                    });
                }
            }
            const config = {
                version: '1.0.0',
                variables
            };
            const typeContent = GlobalBlackboardTypeGenerator.generate(config);
            const typePath = `${typeOutputPath}/GlobalBlackboard.ts`;
            await fileSystem.writeFile(typePath, typeContent);
            return {
                success: true,
                message: '成功生成全局黑板类型',
                outputFiles: [typePath]
            };
        }
        catch (error) {
            return {
                success: false,
                message: `生成全局黑板类型失败: ${error}`,
                errors: [String(error)]
            };
        }
    }
    generateBlackboardTypes(behaviorName, blackboardVars) {
        const lines = [];
        lines.push(`export interface ${behaviorName}Blackboard {`);
        for (const [key, value] of Object.entries(blackboardVars)) {
            const type = this.inferType(value);
            lines.push(`    ${key}: ${type};`);
        }
        lines.push('}');
        return lines.join('\n');
    }
    inferType(value) {
        if (value === null)
            return 'null';
        if (value === undefined)
            return 'undefined';
        if (typeof value === 'string')
            return 'string';
        if (typeof value === 'number')
            return 'number';
        if (typeof value === 'boolean')
            return 'boolean';
        if (Array.isArray(value))
            return 'unknown[]';
        if (typeof value === 'object')
            return 'Record<string, unknown>';
        return 'unknown';
    }
    getCurrentFileName() {
        const treeStore = useTreeStore.getState();
        const pendingPath = treeStore.pendingFilePath;
        if (!pendingPath)
            return null;
        const fileName = pendingPath.split(/[/\\]/).pop();
        if (!fileName)
            return null;
        return fileName.replace('.btree', '');
    }
    validateOptions(options) {
        if (!options.assetOutputPath) {
            return '请选择资产输出路径';
        }
        if (!options.typeOutputPath) {
            return '请选择类型定义输出路径';
        }
        if (options.mode === 'workspace' && options.selectedFiles.length === 0) {
            return '请至少选择一个文件';
        }
        if (options.mode === 'single' && !this.getCurrentFileName()) {
            return '没有打开的行为树文件';
        }
        return null;
    }
    createConfigUI(onOptionsChange, context) {
        return _jsx(BehaviorTreeCompileConfigUI, { onOptionsChange: onOptionsChange, context: context });
    }
}
function BehaviorTreeCompileConfigUI({ onOptionsChange, context }) {
    const { projectPath, moduleContext } = context;
    const { fileSystem, dialog } = moduleContext;
    const [mode, setMode] = useState('workspace');
    const [assetOutputPath, setAssetOutputPath] = useState('');
    const [typeOutputPath, setTypeOutputPath] = useState('');
    const [availableFiles, setAvailableFiles] = useState([]);
    const [selectedFiles, setSelectedFiles] = useState(new Set());
    const [fileFormats, setFileFormats] = useState(new Map());
    const [selectAll, setSelectAll] = useState(true);
    useEffect(() => {
        const loadFiles = async () => {
            if (projectPath) {
                const files = await fileSystem.scanFiles(`${projectPath}/.ecs/behaviors`, '*.btree');
                setAvailableFiles(files);
                setSelectedFiles(new Set(files));
                const formats = new Map();
                files.forEach((file) => formats.set(file, 'binary'));
                setFileFormats(formats);
            }
        };
        loadFiles();
        const savedAssetPath = localStorage.getItem('export-asset-path');
        const savedTypePath = localStorage.getItem('export-type-path');
        if (savedAssetPath)
            setAssetOutputPath(savedAssetPath);
        if (savedTypePath)
            setTypeOutputPath(savedTypePath);
    }, [projectPath]);
    useEffect(() => {
        onOptionsChange({
            mode,
            assetOutputPath,
            typeOutputPath,
            selectedFiles: mode === 'workspace' ? Array.from(selectedFiles) : [],
            fileFormats
        });
    }, [mode, assetOutputPath, typeOutputPath, selectedFiles, fileFormats, onOptionsChange]);
    const handleBrowseAssetPath = async () => {
        const selected = await dialog.openDialog({
            directory: true,
            multiple: false,
            title: '选择资产输出目录',
            defaultPath: assetOutputPath || projectPath || undefined
        });
        if (selected && typeof selected === 'string') {
            setAssetOutputPath(selected);
            localStorage.setItem('export-asset-path', selected);
        }
    };
    const handleBrowseTypePath = async () => {
        const selected = await dialog.openDialog({
            directory: true,
            multiple: false,
            title: '选择类型定义输出目录',
            defaultPath: typeOutputPath || projectPath || undefined
        });
        if (selected && typeof selected === 'string') {
            setTypeOutputPath(selected);
            localStorage.setItem('export-type-path', selected);
        }
    };
    const handleSelectAll = () => {
        if (selectAll) {
            setSelectedFiles(new Set());
            setSelectAll(false);
        }
        else {
            setSelectedFiles(new Set(availableFiles));
            setSelectAll(true);
        }
    };
    const handleToggleFile = (file) => {
        const newSelected = new Set(selectedFiles);
        if (newSelected.has(file)) {
            newSelected.delete(file);
        }
        else {
            newSelected.add(file);
        }
        setSelectedFiles(newSelected);
        setSelectAll(newSelected.size === availableFiles.length);
    };
    const handleFileFormatChange = (file, format) => {
        const newFormats = new Map(fileFormats);
        newFormats.set(file, format);
        setFileFormats(newFormats);
    };
    return (_jsxs("div", { style: { display: 'flex', flexDirection: 'column', gap: '16px' }, children: [_jsxs("div", { style: { display: 'flex', gap: '8px', borderBottom: '1px solid #3e3e3e', paddingBottom: '8px' }, children: [_jsxs("button", { onClick: () => setMode('workspace'), style: {
                            flex: 1,
                            padding: '8px 16px',
                            background: mode === 'workspace' ? '#0e639c' : '#3a3a3a',
                            border: 'none',
                            borderRadius: '4px',
                            color: '#fff',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            gap: '6px',
                            fontSize: '13px'
                        }, children: [_jsx(FolderTree, { size: 16 }), "\u5DE5\u4F5C\u533A\u7F16\u8BD1"] }), _jsxs("button", { onClick: () => setMode('single'), style: {
                            flex: 1,
                            padding: '8px 16px',
                            background: mode === 'single' ? '#0e639c' : '#3a3a3a',
                            border: 'none',
                            borderRadius: '4px',
                            color: '#fff',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            gap: '6px',
                            fontSize: '13px'
                        }, children: [_jsx(File, { size: 16 }), "\u5F53\u524D\u6587\u4EF6"] })] }), _jsxs("div", { children: [_jsx("div", { style: { marginBottom: '8px', fontSize: '13px', fontWeight: 600, color: '#ccc' }, children: "\u8D44\u4EA7\u8F93\u51FA\u8DEF\u5F84" }), _jsxs("div", { style: { display: 'flex', gap: '8px' }, children: [_jsx("input", { type: "text", value: assetOutputPath, onChange: (e) => setAssetOutputPath(e.target.value), placeholder: "\u9009\u62E9\u8D44\u4EA7\u8F93\u51FA\u76EE\u5F55...", style: {
                                    flex: 1,
                                    padding: '8px 12px',
                                    background: '#2d2d2d',
                                    border: '1px solid #3a3a3a',
                                    borderRadius: '4px',
                                    color: '#ccc',
                                    fontSize: '12px'
                                } }), _jsxs("button", { onClick: handleBrowseAssetPath, style: {
                                    padding: '8px 16px',
                                    background: '#0e639c',
                                    border: 'none',
                                    borderRadius: '4px',
                                    color: '#fff',
                                    cursor: 'pointer',
                                    fontSize: '12px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '6px'
                                }, children: [_jsx(FolderOpen, { size: 14 }), "\u6D4F\u89C8"] })] })] }), _jsxs("div", { children: [_jsx("div", { style: { marginBottom: '8px', fontSize: '13px', fontWeight: 600, color: '#ccc' }, children: "TypeScript \u7C7B\u578B\u5B9A\u4E49\u8F93\u51FA\u8DEF\u5F84" }), _jsxs("div", { style: { display: 'flex', gap: '8px' }, children: [_jsx("input", { type: "text", value: typeOutputPath, onChange: (e) => setTypeOutputPath(e.target.value), placeholder: "\u9009\u62E9\u7C7B\u578B\u5B9A\u4E49\u8F93\u51FA\u76EE\u5F55...", style: {
                                    flex: 1,
                                    padding: '8px 12px',
                                    background: '#2d2d2d',
                                    border: '1px solid #3a3a3a',
                                    borderRadius: '4px',
                                    color: '#ccc',
                                    fontSize: '12px'
                                } }), _jsxs("button", { onClick: handleBrowseTypePath, style: {
                                    padding: '8px 16px',
                                    background: '#0e639c',
                                    border: 'none',
                                    borderRadius: '4px',
                                    color: '#fff',
                                    cursor: 'pointer',
                                    fontSize: '12px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '6px'
                                }, children: [_jsx(FolderOpen, { size: 14 }), "\u6D4F\u89C8"] })] })] }), mode === 'workspace' && availableFiles.length > 0 && (_jsxs("div", { children: [_jsxs("div", { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }, children: [_jsxs("div", { style: { fontSize: '13px', fontWeight: 600, color: '#ccc' }, children: ["\u9009\u62E9\u6587\u4EF6 (", selectedFiles.size, "/", availableFiles.length, ")"] }), _jsx("button", { onClick: handleSelectAll, style: {
                                    padding: '4px 12px',
                                    background: '#3a3a3a',
                                    border: 'none',
                                    borderRadius: '3px',
                                    color: '#ccc',
                                    cursor: 'pointer',
                                    fontSize: '12px'
                                }, children: selectAll ? '取消全选' : '全选' })] }), _jsx("div", { style: { maxHeight: '200px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '4px' }, children: availableFiles.map((file) => (_jsxs("div", { style: {
                                display: 'flex',
                                alignItems: 'center',
                                gap: '8px',
                                padding: '8px',
                                background: selectedFiles.has(file) ? '#2a2d2e' : '#1e1e1e',
                                border: `1px solid ${selectedFiles.has(file) ? '#0e639c' : '#3a3a3a'}`,
                                borderRadius: '4px',
                                fontSize: '12px'
                            }, children: [_jsx("input", { type: "checkbox", checked: selectedFiles.has(file), onChange: () => handleToggleFile(file), style: { cursor: 'pointer' } }), _jsx(File, { size: 14, style: { color: '#ab47bc' } }), _jsxs("span", { style: { flex: 1, color: '#ccc' }, children: [file, ".btree"] }), _jsxs("select", { value: fileFormats.get(file) || 'binary', onChange: (e) => handleFileFormatChange(file, e.target.value), onClick: (e) => e.stopPropagation(), style: {
                                        padding: '4px 8px',
                                        background: '#2d2d2d',
                                        border: '1px solid #3a3a3a',
                                        borderRadius: '3px',
                                        color: '#ccc',
                                        fontSize: '11px',
                                        cursor: 'pointer'
                                    }, children: [_jsx("option", { value: "binary", children: "\u4E8C\u8FDB\u5236" }), _jsx("option", { value: "json", children: "JSON" })] })] }, file))) })] }))] }));
}
//# sourceMappingURL=BehaviorTreeCompiler.js.map