import React from 'react';
import { ICompiler, CompileResult, CompilerContext } from '@esengine/editor-core';
export interface BehaviorTreeCompileOptions {
    mode: 'single' | 'workspace';
    assetOutputPath: string;
    typeOutputPath: string;
    selectedFiles: string[];
    fileFormats: Map<string, 'json' | 'binary'>;
}
export declare class BehaviorTreeCompiler implements ICompiler<BehaviorTreeCompileOptions> {
    readonly id = "behavior-tree";
    readonly name = "\u884C\u4E3A\u6811\u7F16\u8BD1\u5668";
    readonly description = "\u5C06\u884C\u4E3A\u6811\u6587\u4EF6\u7F16\u8BD1\u4E3A\u8FD0\u884C\u65F6\u8D44\u4EA7\u548CTypeScript\u7C7B\u578B\u5B9A\u4E49";
    private projectPath;
    compile(options: BehaviorTreeCompileOptions, context: CompilerContext): Promise<CompileResult>;
    private compileFile;
    private generateGlobalBlackboardTypes;
    private generateBlackboardTypes;
    private inferType;
    private getCurrentFileName;
    validateOptions(options: BehaviorTreeCompileOptions): string | null;
    createConfigUI(onOptionsChange: (options: BehaviorTreeCompileOptions) => void, context: CompilerContext): React.ReactElement;
}
//# sourceMappingURL=BehaviorTreeCompiler.d.ts.map