import { NodeTemplate } from '@esengine/behavior-tree';
import { LucideIcon } from 'lucide-react';
export declare const ICON_MAP: Record<string, LucideIcon>;
export declare const ROOT_NODE_TEMPLATE: NodeTemplate;
//# sourceMappingURL=editorConstants.d.ts.map