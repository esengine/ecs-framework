type EventHandler<T = any> = (data: T) => void;
interface Subscription {
    unsubscribe: () => void;
}
export declare enum EditorEvent {
    NODE_CREATED = "node:created",
    NODE_DELETED = "node:deleted",
    NODE_UPDATED = "node:updated",
    NODE_MOVED = "node:moved",
    NODE_SELECTED = "node:selected",
    CONNECTION_ADDED = "connection:added",
    CONNECTION_REMOVED = "connection:removed",
    EXECUTION_STARTED = "execution:started",
    EXECUTION_PAUSED = "execution:paused",
    EXECUTION_RESUMED = "execution:resumed",
    EXECUTION_STOPPED = "execution:stopped",
    EXECUTION_TICK = "execution:tick",
    EXECUTION_NODE_STATUS_CHANGED = "execution:node_status_changed",
    TREE_SAVED = "tree:saved",
    TREE_LOADED = "tree:loaded",
    TREE_VALIDATED = "tree:validated",
    BLACKBOARD_VARIABLE_UPDATED = "blackboard:variable_updated",
    BLACKBOARD_RESTORED = "blackboard:restored",
    CANVAS_ZOOM_CHANGED = "canvas:zoom_changed",
    CANVAS_PAN_CHANGED = "canvas:pan_changed",
    CANVAS_RESET = "canvas:reset",
    COMMAND_EXECUTED = "command:executed",
    COMMAND_UNDONE = "command:undone",
    COMMAND_REDONE = "command:redone"
}
export declare class EditorEventBus {
    private listeners;
    private eventHistory;
    private maxHistorySize;
    on<T = any>(event: EditorEvent | string, handler: EventHandler<T>): Subscription;
    once<T = any>(event: EditorEvent | string, handler: EventHandler<T>): Subscription;
    off<T = any>(event: EditorEvent | string, handler: EventHandler<T>): void;
    emit<T = any>(event: EditorEvent | string, data?: T): void;
    clear(event?: EditorEvent | string): void;
    getListenerCount(event: EditorEvent | string): number;
    getAllEvents(): string[];
    getEventHistory(count?: number): Array<{
        event: string;
        data: any;
        timestamp: number;
    }>;
    clearHistory(): void;
}
export declare function getGlobalEventBus(): EditorEventBus;
export declare function resetGlobalEventBus(): void;
export {};
//# sourceMappingURL=EditorEventBus.d.ts.map