import { BehaviorTree } from '../../domain/models/BehaviorTree';
import { BehaviorTreeAssetSerializer, EditorFormatConverter } from '@esengine/behavior-tree';
/**
 * 行为树序列化器实现
 */
export class BehaviorTreeSerializer {
    constructor(options = {}) {
        this.options = options;
        this.defaultOptions = {
            version: '1.0.0',
            name: 'Untitled Behavior Tree',
            description: '',
            createdAt: new Date().toISOString(),
            modifiedAt: new Date().toISOString()
        };
        this.defaultOptions = { ...this.defaultOptions, ...options };
    }
    /**
     * 序列化行为树
     */
    serialize(tree, format) {
        const treeObject = tree.toObject();
        if (format === 'json') {
            return JSON.stringify(treeObject, null, 2);
        }
        throw new Error(`不支持的序列化格式: ${format}`);
    }
    /**
     * 反序列化行为树
     */
    deserialize(data, format) {
        if (format === 'json') {
            if (typeof data !== 'string') {
                throw new Error('JSON 格式需要字符串数据');
            }
            const obj = JSON.parse(data);
            return BehaviorTree.fromObject(obj);
        }
        throw new Error(`不支持的反序列化格式: ${format}`);
    }
    /**
     * 导出为运行时资产格式
     * @param tree 行为树
     * @param format 导出格式
     * @param options 可选的序列化选项（覆盖默认值）
     */
    exportToRuntimeAsset(tree, format, options) {
        const nodes = tree.nodes.map((node) => ({
            id: node.id,
            template: node.template,
            data: node.data,
            position: node.position.toObject(),
            children: Array.from(node.children)
        }));
        const connections = tree.connections.map((conn) => conn.toObject());
        const blackboard = tree.blackboard.toObject();
        const finalOptions = { ...this.defaultOptions, ...options };
        finalOptions.modifiedAt = new Date().toISOString();
        const editorFormat = {
            version: finalOptions.version,
            metadata: {
                name: finalOptions.name,
                description: finalOptions.description,
                createdAt: finalOptions.createdAt,
                modifiedAt: finalOptions.modifiedAt
            },
            nodes,
            connections,
            blackboard
        };
        const asset = EditorFormatConverter.toAsset(editorFormat);
        if (format === 'json') {
            return BehaviorTreeAssetSerializer.serialize(asset, { format: 'json', pretty: true });
        }
        else if (format === 'binary') {
            return BehaviorTreeAssetSerializer.serialize(asset, { format: 'binary' });
        }
        throw new Error(`不支持的导出格式: ${format}`);
    }
}
//# sourceMappingURL=BehaviorTreeSerializer.js.map