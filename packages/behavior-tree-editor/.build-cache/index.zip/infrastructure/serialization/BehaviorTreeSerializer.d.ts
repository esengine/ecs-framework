import { BehaviorTree } from '../../domain/models/BehaviorTree';
import { ISerializer, SerializationFormat } from '../../domain/interfaces/ISerializer';
/**
 * 序列化选项
 */
export interface SerializationOptions {
    /**
     * 资产版本号
     */
    version?: string;
    /**
     * 资产名称
     */
    name?: string;
    /**
     * 资产描述
     */
    description?: string;
    /**
     * 创建时间
     */
    createdAt?: string;
    /**
     * 修改时间
     */
    modifiedAt?: string;
}
/**
 * 行为树序列化器实现
 */
export declare class BehaviorTreeSerializer implements ISerializer {
    private readonly options;
    private readonly defaultOptions;
    constructor(options?: SerializationOptions);
    /**
     * 序列化行为树
     */
    serialize(tree: BehaviorTree, format: SerializationFormat): string | Uint8Array;
    /**
     * 反序列化行为树
     */
    deserialize(data: string | Uint8Array, format: SerializationFormat): BehaviorTree;
    /**
     * 导出为运行时资产格式
     * @param tree 行为树
     * @param format 导出格式
     * @param options 可选的序列化选项（覆盖默认值）
     */
    exportToRuntimeAsset(tree: BehaviorTree, format: SerializationFormat, options?: SerializationOptions): string | Uint8Array;
}
//# sourceMappingURL=BehaviorTreeSerializer.d.ts.map