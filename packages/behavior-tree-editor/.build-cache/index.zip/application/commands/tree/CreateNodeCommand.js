import { BaseCommand } from '@esengine/editor-core';
/**
 * 创建节点命令
 */
export class CreateNodeCommand extends BaseCommand {
    constructor(state, node) {
        super();
        this.state = state;
        this.node = node;
        this.createdNodeId = node.id;
    }
    execute() {
        const tree = this.state.getTree();
        const newTree = tree.addNode(this.node);
        this.state.setTree(newTree);
    }
    undo() {
        const tree = this.state.getTree();
        const newTree = tree.removeNode(this.createdNodeId);
        this.state.setTree(newTree);
    }
    getDescription() {
        return `创建节点: ${this.node.template.displayName}`;
    }
}
//# sourceMappingURL=CreateNodeCommand.js.map