import { Node } from '../../../domain/models/Node';
import { BaseCommand } from '@esengine/editor-core';
import { ITreeState } from '../ITreeState';
/**
 * 创建节点命令
 */
export declare class CreateNodeCommand extends BaseCommand {
    private readonly state;
    private readonly node;
    private createdNodeId;
    constructor(state: ITreeState, node: Node);
    execute(): void;
    undo(): void;
    getDescription(): string;
}
//# sourceMappingURL=CreateNodeCommand.d.ts.map