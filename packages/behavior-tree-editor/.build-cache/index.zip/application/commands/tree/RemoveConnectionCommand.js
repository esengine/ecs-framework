import { BaseCommand } from '@esengine/editor-core';
/**
 * 移除连接命令
 */
export class RemoveConnectionCommand extends BaseCommand {
    constructor(state, from, to, fromProperty, toProperty) {
        super();
        this.state = state;
        this.from = from;
        this.to = to;
        this.fromProperty = fromProperty;
        this.toProperty = toProperty;
        this.removedConnection = null;
    }
    execute() {
        const tree = this.state.getTree();
        const connection = tree.connections.find((c) => c.matches(this.from, this.to, this.fromProperty, this.toProperty));
        if (!connection) {
            throw new Error(`连接不存在: ${this.from} -> ${this.to}`);
        }
        this.removedConnection = connection;
        const newTree = tree.removeConnection(this.from, this.to, this.fromProperty, this.toProperty);
        this.state.setTree(newTree);
    }
    undo() {
        if (!this.removedConnection) {
            throw new Error('无法撤销：未保存已删除的连接');
        }
        const tree = this.state.getTree();
        const newTree = tree.addConnection(this.removedConnection);
        this.state.setTree(newTree);
    }
    getDescription() {
        return `移除连接: ${this.from} -> ${this.to}`;
    }
}
//# sourceMappingURL=RemoveConnectionCommand.js.map