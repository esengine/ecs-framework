import { BaseCommand } from '@esengine/editor-core';
/**
 * 删除节点命令
 */
export class DeleteNodeCommand extends BaseCommand {
    constructor(state, nodeId) {
        super();
        this.state = state;
        this.nodeId = nodeId;
        this.deletedNode = null;
    }
    execute() {
        const tree = this.state.getTree();
        this.deletedNode = tree.getNode(this.nodeId);
        const newTree = tree.removeNode(this.nodeId);
        this.state.setTree(newTree);
    }
    undo() {
        if (!this.deletedNode) {
            throw new Error('无法撤销：未保存已删除的节点');
        }
        const tree = this.state.getTree();
        const newTree = tree.addNode(this.deletedNode);
        this.state.setTree(newTree);
    }
    getDescription() {
        return `删除节点: ${this.deletedNode?.template.displayName ?? this.nodeId}`;
    }
}
//# sourceMappingURL=DeleteNodeCommand.js.map