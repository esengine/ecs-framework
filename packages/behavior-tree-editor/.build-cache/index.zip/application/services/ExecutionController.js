import { BehaviorTreeExecutor } from '../../utils/BehaviorTreeExecutor';
import { DOMCache } from '../../utils/DOMCache';
import { EditorEvent } from '../../infrastructure/events/EditorEventBus';
export class ExecutionController {
    constructor(config) {
        this.executor = null;
        this.mode = 'idle';
        this.animationFrameId = null;
        this.lastTickTime = 0;
        this.speed = 1.0;
        this.tickCount = 0;
        this.domCache = new DOMCache();
        this.currentNodes = [];
        this.currentConnections = [];
        this.currentBlackboard = {};
        this.stepByStepMode = true;
        this.pendingStatusUpdates = [];
        this.currentlyDisplayedIndex = 0;
        this.lastStepTime = 0;
        this.stepInterval = 200;
        this.config = config;
        this.executor = new BehaviorTreeExecutor();
        this.eventBus = config.eventBus;
        this.hooksManager = config.hooksManager;
    }
    getMode() {
        return this.mode;
    }
    getTickCount() {
        return this.tickCount;
    }
    getSpeed() {
        return this.speed;
    }
    setSpeed(speed) {
        this.speed = speed;
        this.lastTickTime = 0;
    }
    async play(nodes, blackboardVariables, connections) {
        if (this.mode === 'running')
            return;
        this.currentNodes = nodes;
        this.currentConnections = connections;
        this.currentBlackboard = blackboardVariables;
        const context = {
            nodes,
            connections,
            blackboardVariables,
            rootNodeId: this.config.rootNodeId,
            tickCount: 0
        };
        try {
            await this.hooksManager?.triggerBeforePlay(context);
            this.mode = 'running';
            this.tickCount = 0;
            this.lastTickTime = 0;
            if (!this.executor) {
                this.executor = new BehaviorTreeExecutor();
            }
            this.executor.buildTree(nodes, this.config.rootNodeId, blackboardVariables, connections, this.handleExecutionStatusUpdate.bind(this));
            this.executor.start();
            this.animationFrameId = requestAnimationFrame(this.tickLoop.bind(this));
            this.eventBus?.emit(EditorEvent.EXECUTION_STARTED, context);
            await this.hooksManager?.triggerAfterPlay(context);
        }
        catch (error) {
            console.error('Error in play:', error);
            await this.hooksManager?.triggerOnError(error, 'play');
            throw error;
        }
    }
    async pause() {
        try {
            if (this.mode === 'running') {
                await this.hooksManager?.triggerBeforePause();
                this.mode = 'paused';
                if (this.executor) {
                    this.executor.pause();
                }
                if (this.animationFrameId !== null) {
                    cancelAnimationFrame(this.animationFrameId);
                    this.animationFrameId = null;
                }
                this.eventBus?.emit(EditorEvent.EXECUTION_PAUSED);
                await this.hooksManager?.triggerAfterPause();
            }
            else if (this.mode === 'paused') {
                await this.hooksManager?.triggerBeforeResume();
                this.mode = 'running';
                this.lastTickTime = 0;
                if (this.executor) {
                    this.executor.resume();
                }
                this.animationFrameId = requestAnimationFrame(this.tickLoop.bind(this));
                this.eventBus?.emit(EditorEvent.EXECUTION_RESUMED);
                await this.hooksManager?.triggerAfterResume();
            }
        }
        catch (error) {
            console.error('Error in pause/resume:', error);
            await this.hooksManager?.triggerOnError(error, 'pause');
            throw error;
        }
    }
    async stop() {
        try {
            await this.hooksManager?.triggerBeforeStop();
            this.mode = 'idle';
            this.tickCount = 0;
            this.lastTickTime = 0;
            this.lastStepTime = 0;
            this.pendingStatusUpdates = [];
            this.currentlyDisplayedIndex = 0;
            this.domCache.clearAllStatusTimers();
            this.domCache.clearStatusCache();
            this.config.onExecutionStatusUpdate(new Map(), new Map());
            if (this.animationFrameId !== null) {
                cancelAnimationFrame(this.animationFrameId);
                this.animationFrameId = null;
            }
            if (this.executor) {
                this.executor.stop();
            }
            this.eventBus?.emit(EditorEvent.EXECUTION_STOPPED);
            await this.hooksManager?.triggerAfterStop();
        }
        catch (error) {
            console.error('Error in stop:', error);
            await this.hooksManager?.triggerOnError(error, 'stop');
            throw error;
        }
    }
    async reset() {
        await this.stop();
        if (this.executor) {
            this.executor.cleanup();
        }
    }
    step() {
        // 单步执行功能预留
    }
    updateBlackboardVariable(key, value) {
        if (this.executor && this.mode !== 'idle') {
            this.executor.updateBlackboardVariable(key, value);
        }
    }
    getBlackboardVariables() {
        if (this.executor) {
            return this.executor.getBlackboardVariables();
        }
        return {};
    }
    updateNodes(nodes) {
        if (this.mode === 'idle' || !this.executor) {
            return;
        }
        this.currentNodes = nodes;
        this.executor.buildTree(nodes, this.config.rootNodeId, this.currentBlackboard, this.currentConnections, this.handleExecutionStatusUpdate.bind(this));
        this.executor.start();
    }
    clearDOMCache() {
        this.domCache.clearAll();
    }
    destroy() {
        this.stop();
        if (this.executor) {
            this.executor.destroy();
            this.executor = null;
        }
    }
    tickLoop(currentTime) {
        if (this.mode !== 'running') {
            return;
        }
        if (!this.executor) {
            return;
        }
        if (this.stepByStepMode) {
            this.handleStepByStepExecution(currentTime);
        }
        else {
            this.handleNormalExecution(currentTime);
        }
        this.animationFrameId = requestAnimationFrame(this.tickLoop.bind(this));
    }
    handleNormalExecution(currentTime) {
        const baseTickInterval = 16.67;
        const scaledTickInterval = baseTickInterval / this.speed;
        if (this.lastTickTime === 0) {
            this.lastTickTime = currentTime;
        }
        const elapsed = currentTime - this.lastTickTime;
        if (elapsed >= scaledTickInterval) {
            const deltaTime = baseTickInterval / 1000;
            this.executor.tick(deltaTime);
            this.tickCount = this.executor.getTickCount();
            this.config.onTickCountUpdate(this.tickCount);
            this.lastTickTime = currentTime;
        }
    }
    handleStepByStepExecution(currentTime) {
        if (this.lastStepTime === 0) {
            this.lastStepTime = currentTime;
        }
        const stepElapsed = currentTime - this.lastStepTime;
        const actualStepInterval = this.stepInterval / this.speed;
        if (stepElapsed >= actualStepInterval) {
            if (this.currentlyDisplayedIndex < this.pendingStatusUpdates.length) {
                this.displayNextNode();
                this.lastStepTime = currentTime;
            }
            else {
                if (this.lastTickTime === 0) {
                    this.lastTickTime = currentTime;
                }
                const tickElapsed = currentTime - this.lastTickTime;
                const baseTickInterval = 16.67;
                const scaledTickInterval = baseTickInterval / this.speed;
                if (tickElapsed >= scaledTickInterval) {
                    const deltaTime = baseTickInterval / 1000;
                    this.executor.tick(deltaTime);
                    this.tickCount = this.executor.getTickCount();
                    this.config.onTickCountUpdate(this.tickCount);
                    this.lastTickTime = currentTime;
                }
            }
        }
    }
    displayNextNode() {
        if (this.currentlyDisplayedIndex >= this.pendingStatusUpdates.length) {
            return;
        }
        const statusesToDisplay = this.pendingStatusUpdates.slice(0, this.currentlyDisplayedIndex + 1);
        const currentNode = this.pendingStatusUpdates[this.currentlyDisplayedIndex];
        if (!currentNode) {
            return;
        }
        const statusMap = new Map();
        const orderMap = new Map();
        statusesToDisplay.forEach((s) => {
            statusMap.set(s.nodeId, s.status);
            if (s.executionOrder !== undefined) {
                orderMap.set(s.nodeId, s.executionOrder);
            }
        });
        const nodeName = this.currentNodes.find(n => n.id === currentNode.nodeId)?.template.displayName || 'Unknown';
        console.log(`[StepByStep] Displaying ${this.currentlyDisplayedIndex + 1}/${this.pendingStatusUpdates.length} | ${nodeName} | Order: ${currentNode.executionOrder} | ID: ${currentNode.nodeId}`);
        this.config.onExecutionStatusUpdate(statusMap, orderMap);
        this.currentlyDisplayedIndex++;
    }
    handleExecutionStatusUpdate(statuses, logs, runtimeBlackboardVars) {
        this.config.onLogsUpdate([...logs]);
        if (runtimeBlackboardVars) {
            this.config.onBlackboardUpdate(runtimeBlackboardVars);
        }
        if (this.stepByStepMode) {
            const statusesWithOrder = statuses.filter(s => s.executionOrder !== undefined);
            if (statusesWithOrder.length > 0) {
                const minOrder = Math.min(...statusesWithOrder.map(s => s.executionOrder));
                if (minOrder === 1 || this.pendingStatusUpdates.length === 0) {
                    this.pendingStatusUpdates = statusesWithOrder.sort((a, b) => (a.executionOrder || 0) - (b.executionOrder || 0));
                    this.currentlyDisplayedIndex = 0;
                    this.lastStepTime = 0;
                }
                else {
                    const maxExistingOrder = this.pendingStatusUpdates.length > 0
                        ? Math.max(...this.pendingStatusUpdates.map(s => s.executionOrder || 0))
                        : 0;
                    const newStatuses = statusesWithOrder.filter(s => (s.executionOrder || 0) > maxExistingOrder);
                    if (newStatuses.length > 0) {
                        console.log(`[StepByStep] Appending ${newStatuses.length} new nodes, orders:`, newStatuses.map(s => s.executionOrder));
                        this.pendingStatusUpdates = [
                            ...this.pendingStatusUpdates,
                            ...newStatuses
                        ].sort((a, b) => (a.executionOrder || 0) - (b.executionOrder || 0));
                    }
                }
            }
        }
        else {
            const statusMap = new Map();
            const orderMap = new Map();
            statuses.forEach((s) => {
                statusMap.set(s.nodeId, s.status);
                if (s.executionOrder !== undefined) {
                    orderMap.set(s.nodeId, s.executionOrder);
                }
            });
            this.config.onExecutionStatusUpdate(statusMap, orderMap);
        }
    }
    updateConnectionStyles(statusMap, connections) {
        if (!connections)
            return;
        connections.forEach((conn) => {
            const connKey = `${conn.from}-${conn.to}`;
            const pathElement = this.domCache.getConnection(connKey);
            if (!pathElement) {
                return;
            }
            const fromStatus = statusMap[conn.from];
            const toStatus = statusMap[conn.to];
            const isActive = fromStatus === 'running' || toStatus === 'running';
            if (conn.connectionType === 'property') {
                this.domCache.setConnectionAttribute(connKey, 'stroke', '#9c27b0');
                this.domCache.setConnectionAttribute(connKey, 'stroke-width', '2');
            }
            else if (isActive) {
                this.domCache.setConnectionAttribute(connKey, 'stroke', '#ffa726');
                this.domCache.setConnectionAttribute(connKey, 'stroke-width', '3');
            }
            else {
                const isExecuted = this.domCache.hasNodeClass(conn.from, 'executed') &&
                    this.domCache.hasNodeClass(conn.to, 'executed');
                if (isExecuted) {
                    this.domCache.setConnectionAttribute(connKey, 'stroke', '#4caf50');
                    this.domCache.setConnectionAttribute(connKey, 'stroke-width', '2.5');
                }
                else {
                    this.domCache.setConnectionAttribute(connKey, 'stroke', '#0e639c');
                    this.domCache.setConnectionAttribute(connKey, 'stroke-width', '2');
                }
            }
        });
    }
    setConnections(connections) {
        if (this.mode !== 'idle') {
            const currentStatuses = {};
            connections.forEach((conn) => {
                const fromStatus = this.domCache.getLastStatus(conn.from);
                const toStatus = this.domCache.getLastStatus(conn.to);
                if (fromStatus)
                    currentStatuses[conn.from] = fromStatus;
                if (toStatus)
                    currentStatuses[conn.to] = toStatus;
            });
            this.updateConnectionStyles(currentStatuses, connections);
        }
    }
}
//# sourceMappingURL=ExecutionController.js.map