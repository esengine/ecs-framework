import { create } from 'zustand';
import { BehaviorTree } from '../../domain/models/BehaviorTree';
import { useTreeStore } from '../../stores/useTreeStore';
import { Blackboard } from '../../domain/models/Blackboard';
import { createRootNode, ROOT_NODE_ID } from '../../domain/constants/RootNode';
const createInitialTree = () => {
    const rootNode = createRootNode();
    return new BehaviorTree([rootNode], [], Blackboard.empty(), ROOT_NODE_ID);
};
/**
 * 行为树数据 Store
 * 实现 ITreeState 接口，供命令使用
 */
export const useBehaviorTreeDataStore = create((set) => ({
    tree: createInitialTree(),
    setTree: (tree) => set({ tree }),
    reset: () => set({ tree: createInitialTree() })
}));
/**
 * TreeState 适配器
 * 将 Zustand Store 适配为 ITreeState 接口
 * 同步更新领域层和表现层的状态
 */
export class TreeStateAdapter {
    getTree() {
        return useBehaviorTreeDataStore.getState().tree;
    }
    setTree(tree) {
        useBehaviorTreeDataStore.getState().setTree(tree);
        const nodes = Array.from(tree.nodes);
        const connections = Array.from(tree.connections);
        useTreeStore.getState().setNodes(nodes);
        useTreeStore.getState().setConnections(connections);
    }
}
//# sourceMappingURL=BehaviorTreeDataStore.js.map