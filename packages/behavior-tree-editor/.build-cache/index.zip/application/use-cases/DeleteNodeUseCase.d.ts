import { CommandManager } from '@esengine/editor-core';
import { ITreeState } from '../commands/ITreeState';
/**
 * 删除节点用例
 * 删除节点时会自动删除相关连接
 */
export declare class DeleteNodeUseCase {
    private readonly commandManager;
    private readonly treeState;
    constructor(commandManager: CommandManager, treeState: ITreeState);
    /**
     * 删除单个节点
     */
    execute(nodeId: string): void;
    /**
     * 批量删除节点
     */
    executeBatch(nodeIds: string[]): void;
}
//# sourceMappingURL=DeleteNodeUseCase.d.ts.map