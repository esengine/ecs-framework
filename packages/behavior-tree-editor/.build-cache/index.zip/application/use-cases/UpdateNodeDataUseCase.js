import { UpdateNodeDataCommand } from '../commands/tree/UpdateNodeDataCommand';
/**
 * 更新节点数据用例
 */
export class UpdateNodeDataUseCase {
    constructor(commandManager, treeState) {
        this.commandManager = commandManager;
        this.treeState = treeState;
    }
    /**
     * 更新节点数据
     */
    execute(nodeId, data) {
        const command = new UpdateNodeDataCommand(this.treeState, nodeId, data);
        this.commandManager.execute(command);
    }
}
//# sourceMappingURL=UpdateNodeDataUseCase.js.map