import { MoveNodeCommand } from '../commands/tree/MoveNodeCommand';
/**
 * 移动节点用例
 */
export class MoveNodeUseCase {
    constructor(commandManager, treeState) {
        this.commandManager = commandManager;
        this.treeState = treeState;
    }
    /**
     * 移动单个节点
     */
    execute(nodeId, newPosition) {
        const command = new MoveNodeCommand(this.treeState, nodeId, newPosition);
        this.commandManager.execute(command);
    }
    /**
     * 批量移动节点
     */
    executeBatch(moves) {
        const commands = moves.map(({ nodeId, position }) => new MoveNodeCommand(this.treeState, nodeId, position));
        this.commandManager.executeBatch(commands);
    }
}
//# sourceMappingURL=MoveNodeUseCase.js.map