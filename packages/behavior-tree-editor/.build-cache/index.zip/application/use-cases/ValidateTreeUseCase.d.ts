import { IValidator, ValidationResult } from '../../domain/interfaces/IValidator';
import { ITreeState } from '../commands/ITreeState';
/**
 * 验证行为树用例
 */
export declare class ValidateTreeUseCase {
    private readonly validator;
    private readonly treeState;
    constructor(validator: IValidator, treeState: ITreeState);
    /**
     * 验证当前行为树
     */
    execute(): ValidationResult;
    /**
     * 验证并抛出错误（如果验证失败）
     */
    executeAndThrow(): void;
}
//# sourceMappingURL=ValidateTreeUseCase.d.ts.map