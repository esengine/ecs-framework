import { CommandManager } from '@esengine/editor-core';
import { ITreeState } from '../commands/ITreeState';
/**
 * 移除连接用例
 */
export declare class RemoveConnectionUseCase {
    private readonly commandManager;
    private readonly treeState;
    constructor(commandManager: CommandManager, treeState: ITreeState);
    /**
     * 执行移除连接操作
     */
    execute(from: string, to: string, fromProperty?: string, toProperty?: string): void;
}
//# sourceMappingURL=RemoveConnectionUseCase.d.ts.map