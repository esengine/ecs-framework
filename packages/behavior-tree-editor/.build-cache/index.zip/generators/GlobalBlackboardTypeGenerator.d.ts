import { GlobalBlackboardConfig } from '@esengine/behavior-tree';
/**
 * 类型生成配置选项
 */
export interface TypeGenerationOptions {
    /** 常量名称大小写风格 */
    constantCase?: 'UPPER_SNAKE' | 'camelCase' | 'PascalCase';
    /** 常量对象名称 */
    constantsName?: string;
    /** 接口名称 */
    interfaceName?: string;
    /** 类型别名名称 */
    typeAliasName?: string;
    /** 包装类名称 */
    wrapperClassName?: string;
    /** 默认值对象名称 */
    defaultsName?: string;
    /** 导入路径 */
    importPath?: string;
    /** 是否生成常量对象 */
    includeConstants?: boolean;
    /** 是否生成接口 */
    includeInterface?: boolean;
    /** 是否生成类型别名 */
    includeTypeAlias?: boolean;
    /** 是否生成包装类 */
    includeWrapperClass?: boolean;
    /** 是否生成默认值 */
    includeDefaults?: boolean;
    /** 自定义头部注释 */
    customHeader?: string;
    /** 使用单引号还是双引号 */
    quoteStyle?: 'single' | 'double';
    /** 是否在文件末尾添加换行 */
    trailingNewline?: boolean;
}
/**
 * 全局黑板 TypeScript 类型生成器
 *
 * 将全局黑板配置导出为 TypeScript 类型定义，提供：
 * - 编译时类型检查
 * - IDE 自动补全
 * - 避免拼写错误
 * - 重构友好
 */
export declare class GlobalBlackboardTypeGenerator {
    /**
     * 默认生成选项
     */
    static readonly DEFAULT_OPTIONS: Required<TypeGenerationOptions>;
    /**
     * 生成 TypeScript 类型定义代码
     *
     * @param config 全局黑板配置
     * @param options 生成选项
     * @returns TypeScript 代码字符串
     *
     * @example
     * ```typescript
     * // 使用默认选项
     * const code = GlobalBlackboardTypeGenerator.generate(config);
     *
     * // 自定义命名
     * const code = GlobalBlackboardTypeGenerator.generate(config, {
     *     constantsName: 'GameVars',
     *     wrapperClassName: 'GameBlackboard'
     * });
     *
     * // 只生成接口和类型别名，不生成包装类
     * const code = GlobalBlackboardTypeGenerator.generate(config, {
     *     includeWrapperClass: false,
     *     includeDefaults: false
     * });
     * ```
     */
    static generate(config: GlobalBlackboardConfig, options?: TypeGenerationOptions): string;
    /**
     * 生成文件头部注释
     */
    private static generateHeader;
    /**
     * 生成常量对象
     */
    private static generateConstants;
    /**
     * 生成接口定义
     */
    private static generateInterface;
    /**
     * 生成类型别名
     */
    private static generateTypeAliases;
    /**
     * 生成类型安全包装类
     */
    private static generateTypedClass;
    /**
     * 生成默认值配置
     */
    private static generateDefaults;
    /**
     * 按命名空间分组变量
     */
    private static groupVariablesByNamespace;
    /**
     * 将变量名转换为常量名（UPPER_SNAKE_CASE）
     */
    private static toConstantName;
    /**
     * 转换为 PascalCase
     */
    private static toPascalCase;
    /**
     * 映射黑板类型到 TypeScript 类型
     */
    private static mapBlackboardTypeToTS;
    /**
     * 格式化值为 TypeScript 字面量
     */
    private static formatValue;
    /**
     * 根据指定的大小写风格转换变量名
     */
    private static transformName;
    /**
     * 转换为 camelCase
     */
    private static toCamelCase;
}
//# sourceMappingURL=GlobalBlackboardTypeGenerator.d.ts.map